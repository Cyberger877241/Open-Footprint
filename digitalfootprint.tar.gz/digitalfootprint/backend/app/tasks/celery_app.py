"""
DigitalFootprint — Celery Task Queue
======================================
Async task definitions for connector jobs and search orchestration.
Uses Redis as both broker and result backend.

Workers can be scaled horizontally:
    celery -A app.tasks.celery_app worker --concurrency=8
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any, Optional

from celery import Celery
from celery.signals import worker_ready

from app.config import settings

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# Celery app
# ──────────────────────────────────────────────────────────────

celery_app = Celery(
    "digitalfootprint",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.tasks.search_tasks"],
)

celery_app.conf.update(
    # Serialization
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    # Timezone
    timezone="UTC",
    enable_utc=True,
    # Task behavior
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_track_started=True,
    # Result TTL: keep results for 24 hours
    result_expires=86400,
    # Retry policy
    task_max_retries=3,
    task_default_retry_delay=60,
    # Routing
    task_routes={
        "app.tasks.search_tasks.run_full_search": {"queue": "default"},
        "app.tasks.search_tasks.run_connector": {"queue": "connectors"},
    },
    # Worker settings
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=100,
)


@worker_ready.connect
def on_worker_ready(sender, **kwargs):
    logger.info("DigitalFootprint Celery worker ready")
