"""
DigitalFootprint — Search Tasks
================================
Celery tasks that power the async search pipeline.

Flow:
  POST /search
    → creates SearchJob in Postgres
    → dispatches run_full_search.delay()
    → returns job_id immediately

  run_full_search (Celery worker)
    → calls orchestrator.search()
    → runs identity resolution
    → writes Neo4j graph
    → saves result to Postgres
    → marks job complete
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from typing import Any, Optional

from celery import Task
from sqlalchemy import select, update

from app.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)


class SearchTask(Task):
    """Base task with shared DB + Neo4j connection lifecycle."""

    _db_session = None
    _neo4j = None

    @property
    def neo4j(self):
        if self._neo4j is None:
            from app.database.neo4j_db import get_neo4j
            self._neo4j = get_neo4j()
        return self._neo4j


@celery_app.task(
    bind=True,
    base=SearchTask,
    name="app.tasks.search_tasks.run_full_search",
    queue="default",
    max_retries=2,
    soft_time_limit=300,  # 5 min soft limit
    time_limit=360,       # 6 min hard limit
)
def run_full_search(
    self,
    job_id: str,
    query: str,
    search_type: str,
    include_connectors: Optional[list[str]] = None,
) -> dict[str, Any]:
    """
    Main search task. Runs the full OSINT pipeline:
      1. Update job status → running
      2. Run orchestrator (connectors + agent)
      3. Run identity resolution
      4. Write identity graph to Neo4j
      5. Persist result to Postgres
      6. Update job status → completed
    """
    logger.info(f"[Task:{job_id}] Starting search for query={query!r}")

    return asyncio.run(_async_full_search(
        task=self,
        job_id=job_id,
        query=query,
        search_type=search_type,
        include_connectors=include_connectors,
    ))


async def _async_full_search(
    task,
    job_id: str,
    query: str,
    search_type: str,
    include_connectors: Optional[list[str]],
) -> dict[str, Any]:
    """Async implementation of the full search pipeline."""
    from app.database.postgres import AsyncSessionLocal, SearchJob, SearchResultRecord
    from app.agent.orchestrator import SearchOrchestrator
    from app.identity.resolver import get_resolver
    from app.database.neo4j_db import get_neo4j
    from app.models.schemas import SearchType, JobStatus
    from sqlalchemy import update

    start_time = datetime.utcnow()

    # ── Step 1: Mark job as running ──────────────────────────
    async with AsyncSessionLocal() as db:
        await db.execute(
            update(SearchJob)
            .where(SearchJob.id == job_id)
            .values(
                status=JobStatus.RUNNING.value,
                started_at=start_time,
                celery_task_id=task.request.id,
            )
        )
        await db.commit()

    try:
        # ── Step 2: Run orchestrator (connectors + agent) ────
        orchestrator = SearchOrchestrator()
        search_result = await orchestrator.search(
            query=query,
            search_type=SearchType(search_type),
            include_connectors=include_connectors,
        )

        connector_results = search_result["connector_results"]
        agent_summary = search_result.get("agent_summary")

        # ── Step 3: Identity resolution ──────────────────────
        resolver = get_resolver()
        profiles = resolver.resolve(query, connector_results)

        # ── Step 4: Write to Neo4j graph ──────────────────────
        neo4j = get_neo4j()
        try:
            for profile in profiles:
                await neo4j.upsert_person(
                    person_id=profile["profile_id"],
                    name=profile.get("primary_identity"),
                    confidence=profile["confidence_score"],
                    job_id=job_id,
                )
                for email in profile.get("emails", []):
                    await neo4j.link_email(profile["profile_id"], email)
                for username in profile.get("usernames", []):
                    await neo4j.link_username(profile["profile_id"], username, "unknown")
                for sp in profile.get("social_profiles", []):
                    await neo4j.link_username(
                        profile["profile_id"],
                        sp["username"],
                        sp["platform"],
                        sp.get("url"),
                    )
        except Exception as e:
            logger.warning(f"[Task:{job_id}] Neo4j write failed (non-fatal): {e}")

        # ── Step 5: Build graph visualization data ────────────
        try:
            graph_data = await neo4j.get_identity_graph(job_id)
        except Exception:
            graph_data = {"nodes": [], "edges": []}

        # ── Step 6: Compute summary stats ─────────────────────
        all_emails = list({e for p in profiles for e in p.get("emails", [])})
        all_profiles = profiles
        all_mentions = sum(
            (p.get("mentions") or {}).get("total_mentions", 0) for p in profiles
        )
        overall_confidence = (
            sum(p["confidence_score"] for p in profiles) / len(profiles)
            if profiles else 0.0
        )

        completed_at = datetime.utcnow()
        duration = (completed_at - start_time).total_seconds()

        # ── Step 7: Build result payload ─────────────────────
        result_payload = {
            "job_id": job_id,
            "query": query,
            "search_type": search_type,
            "status": JobStatus.COMPLETED.value,
            "created_at": start_time.isoformat(),
            "completed_at": completed_at.isoformat(),
            "duration_seconds": duration,
            "profiles": profiles,
            "connector_results": connector_results,
            "graph_nodes": graph_data.get("nodes", []),
            "graph_edges": graph_data.get("edges", []),
            "total_emails": len(all_emails),
            "total_profiles": len(all_profiles),
            "total_mentions": all_mentions,
            "overall_confidence": round(overall_confidence, 3),
            "agent_summary": agent_summary,
            "error": None,
        }

        # ── Step 8: Persist to Postgres ───────────────────────
        async with AsyncSessionLocal() as db:
            result_record = SearchResultRecord(
                job_id=job_id,
                query=query,
                result_json=result_payload,
                total_profiles=len(all_profiles),
                total_emails=len(all_emails),
                total_mentions=all_mentions,
                overall_confidence=overall_confidence,
            )
            db.add(result_record)

            await db.execute(
                update(SearchJob)
                .where(SearchJob.id == job_id)
                .values(
                    status=JobStatus.COMPLETED.value,
                    completed_at=completed_at,
                    duration_seconds=duration,
                )
            )
            await db.commit()

        logger.info(
            f"[Task:{job_id}] Completed in {duration:.1f}s — "
            f"{len(profiles)} profiles, {len(all_emails)} emails"
        )
        return result_payload

    except Exception as e:
        logger.error(f"[Task:{job_id}] Search failed: {e}", exc_info=True)

        # Mark job as failed
        async with AsyncSessionLocal() as db:
            await db.execute(
                update(SearchJob)
                .where(SearchJob.id == job_id)
                .values(
                    status=JobStatus.FAILED.value,
                    completed_at=datetime.utcnow(),
                    error=str(e),
                )
            )
            await db.commit()

        raise
