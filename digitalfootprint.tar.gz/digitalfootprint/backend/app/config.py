"""
DigitalFootprint — Central Configuration
=========================================
All settings are loaded from environment variables (or .env file).
Use `settings` singleton throughout the app.
"""
from functools import lru_cache
from typing import Literal, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── App ─────────────────────────────────────────────────
    APP_NAME: str = "DigitalFootprint"
    DEBUG: bool = False
    SECRET_KEY: str = "change-me-in-production"
    ALLOWED_ORIGINS: str = "http://localhost:3000"

    # ── Database ─────────────────────────────────────────────
    POSTGRES_URL: str = (
        "postgresql+asyncpg://df_user:df_pass@localhost:5432/digitalfootprint"
    )
    POSTGRES_URL_SYNC: str = (
        "postgresql://df_user:df_pass@localhost:5432/digitalfootprint"
    )

    NEO4J_URI: str = "bolt://localhost:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "password"

    # ── Redis / Celery ────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/1"

    # ── API Keys ──────────────────────────────────────────────
    HIBP_API_KEY: Optional[str] = None
    HUNTER_API_KEY: Optional[str] = None
    GITHUB_TOKEN: Optional[str] = None
    SERPAPI_KEY: Optional[str] = None
    NEWS_API_KEY: Optional[str] = None

    # ── LLM ───────────────────────────────────────────────────
    OPENAI_API_KEY: Optional[str] = None
    ANTHROPIC_API_KEY: Optional[str] = None
    LLM_PROVIDER: Literal["openai", "anthropic"] = "openai"
    LLM_MODEL: str = "gpt-4o-mini"

    # ── Sherlock ──────────────────────────────────────────────
    SHERLOCK_TIMEOUT: int = 10

    # ── Rate Limiting ─────────────────────────────────────────
    API_RATE_LIMIT: int = 30  # requests per minute

    # ── Embeddings ────────────────────────────────────────────
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in self.ALLOWED_ORIGINS.split(",")]

    @property
    def has_hibp(self) -> bool:
        return bool(self.HIBP_API_KEY)

    @property
    def has_hunter(self) -> bool:
        return bool(self.HUNTER_API_KEY)

    @property
    def has_github(self) -> bool:
        return bool(self.GITHUB_TOKEN)

    @property
    def has_serpapi(self) -> bool:
        return bool(self.SERPAPI_KEY)

    @property
    def has_news(self) -> bool:
        return bool(self.NEWS_API_KEY)

    @property
    def has_llm(self) -> bool:
        if self.LLM_PROVIDER == "openai":
            return bool(self.OPENAI_API_KEY)
        return bool(self.ANTHROPIC_API_KEY)


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
