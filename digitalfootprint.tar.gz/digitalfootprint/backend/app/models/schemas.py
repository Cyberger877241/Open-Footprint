"""
DigitalFootprint — Data Schemas
================================
Pydantic v2 models for all API request/response structures.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field, HttpUrl


# ──────────────────────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────────────────────

class SearchType(str, Enum):
    EMAIL = "email"
    USERNAME = "username"
    NAME = "name"
    COMBINED = "combined"


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"


class ConnectorStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    RATE_LIMITED = "rate_limited"


# ──────────────────────────────────────────────────────────────
# Search Request / Response
# ──────────────────────────────────────────────────────────────

class SearchRequest(BaseModel):
    """
    POST /search — query payload.
    At least one field is required.
    """
    query: str = Field(
        ...,
        description="Primary search query (email, username, full name, or mixed)",
        examples=["johndoe", "john.doe@gmail.com", "John Doe"],
    )
    search_type: SearchType = Field(
        default=SearchType.COMBINED,
        description="Hint to the orchestrator about query format",
    )
    include_connectors: Optional[list[str]] = Field(
        default=None,
        description="Allowlist of connectors to run. None = run all available.",
        examples=[["github", "haveibeenpwned"]],
    )
    max_depth: int = Field(
        default=1,
        ge=1,
        le=3,
        description="Graph traversal depth for identity linking",
    )


class SearchJobResponse(BaseModel):
    """Returned immediately on POST /search before results are ready."""
    job_id: str
    status: JobStatus
    message: str
    created_at: datetime


# ──────────────────────────────────────────────────────────────
# Connector Results
# ──────────────────────────────────────────────────────────────

class ConnectorResult(BaseModel):
    connector: str
    status: ConnectorStatus
    data: dict[str, Any] = Field(default_factory=dict)
    error: Optional[str] = None
    duration_ms: Optional[float] = None


# ──────────────────────────────────────────────────────────────
# Email Intelligence
# ──────────────────────────────────────────────────────────────

class BreachRecord(BaseModel):
    name: str
    domain: str
    breach_date: Optional[str] = None
    description: Optional[str] = None
    data_classes: list[str] = Field(default_factory=list)
    is_verified: bool = False
    is_sensitive: bool = False


class EmailIntelligence(BaseModel):
    email: str
    breaches: list[BreachRecord] = Field(default_factory=list)
    breach_count: int = 0
    hunter_sources: list[dict[str, Any]] = Field(default_factory=list)
    hunter_score: Optional[int] = None


# ──────────────────────────────────────────────────────────────
# Developer Footprint
# ──────────────────────────────────────────────────────────────

class GitHubRepo(BaseModel):
    name: str
    full_name: str
    description: Optional[str] = None
    url: str
    language: Optional[str] = None
    stars: int = 0
    forks: int = 0
    topics: list[str] = Field(default_factory=list)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class GitHubCommitEmail(BaseModel):
    email: str
    commit_count: int
    repos: list[str] = Field(default_factory=list)


class DeveloperFootprint(BaseModel):
    username: str
    name: Optional[str] = None
    bio: Optional[str] = None
    avatar_url: Optional[str] = None
    location: Optional[str] = None
    blog: Optional[str] = None
    company: Optional[str] = None
    public_repos: int = 0
    followers: int = 0
    following: int = 0
    created_at: Optional[str] = None
    repos: list[GitHubRepo] = Field(default_factory=list)
    commit_emails: list[GitHubCommitEmail] = Field(default_factory=list)
    languages: dict[str, int] = Field(default_factory=dict)


# ──────────────────────────────────────────────────────────────
# Username / Social Presence
# ──────────────────────────────────────────────────────────────

class SocialProfile(BaseModel):
    platform: str
    username: str
    url: str
    exists: bool
    profile_data: dict[str, Any] = Field(default_factory=dict)


class UsernameSearchResult(BaseModel):
    username: str
    profiles_found: list[SocialProfile] = Field(default_factory=list)
    total_found: int = 0


# ──────────────────────────────────────────────────────────────
# Mentions / Content
# ──────────────────────────────────────────────────────────────

class MentionResult(BaseModel):
    title: str
    url: str
    source: str
    snippet: Optional[str] = None
    published_at: Optional[str] = None
    relevance_score: Optional[float] = None


class ContentMentions(BaseModel):
    query: str
    news_articles: list[MentionResult] = Field(default_factory=list)
    web_results: list[MentionResult] = Field(default_factory=list)
    total_mentions: int = 0


# ──────────────────────────────────────────────────────────────
# Identity Resolution
# ──────────────────────────────────────────────────────────────

class IdentityLink(BaseModel):
    source_id: str
    target_id: str
    relationship: str  # e.g. "same_person", "shares_email", "shares_username"
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: list[str] = Field(default_factory=list)


class ResolvedProfile(BaseModel):
    """A single unified identity cluster."""
    profile_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    confidence_score: float = Field(ge=0.0, le=1.0)

    # Linked identifiers
    emails: list[str] = Field(default_factory=list)
    usernames: list[str] = Field(default_factory=list)
    names: list[str] = Field(default_factory=list)
    locations: list[str] = Field(default_factory=list)
    websites: list[str] = Field(default_factory=list)

    # Source data
    github: Optional[DeveloperFootprint] = None
    email_intel: list[EmailIntelligence] = Field(default_factory=list)
    social_profiles: list[SocialProfile] = Field(default_factory=list)
    mentions: Optional[ContentMentions] = None

    # Graph
    identity_links: list[IdentityLink] = Field(default_factory=list)

    # Meta
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    primary_identity: Optional[str] = None  # best guess at "real name"


# ──────────────────────────────────────────────────────────────
# Final Search Result (GET /result/{id})
# ──────────────────────────────────────────────────────────────

class SearchResult(BaseModel):
    """Full result returned by GET /result/{job_id}."""
    job_id: str
    query: str
    search_type: SearchType
    status: JobStatus
    created_at: datetime
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None

    # Core outputs
    profiles: list[ResolvedProfile] = Field(default_factory=list)
    connector_results: list[ConnectorResult] = Field(default_factory=list)

    # Graph data (for frontend visualization)
    graph_nodes: list[dict[str, Any]] = Field(default_factory=list)
    graph_edges: list[dict[str, Any]] = Field(default_factory=list)

    # Summary
    total_emails: int = 0
    total_profiles: int = 0
    total_mentions: int = 0
    overall_confidence: float = 0.0

    error: Optional[str] = None


# ──────────────────────────────────────────────────────────────
# Misc
# ──────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    version: str
    connectors_available: list[str]
    services: dict[str, str]
