"""
DigitalFootprint — PostgreSQL Database Layer
=============================================
Async SQLAlchemy engine + ORM models for persistent storage
of search jobs and results.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import AsyncGenerator

from sqlalchemy import JSON, Column, DateTime, Float, Integer, String, Text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.config import settings


# ──────────────────────────────────────────────────────────────
# Engine
# ──────────────────────────────────────────────────────────────

engine = create_async_engine(
    settings.POSTGRES_URL,
    echo=settings.DEBUG,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


# ──────────────────────────────────────────────────────────────
# Base
# ──────────────────────────────────────────────────────────────

class Base(DeclarativeBase):
    pass


# ──────────────────────────────────────────────────────────────
# ORM Models
# ──────────────────────────────────────────────────────────────

class SearchJob(Base):
    """Tracks every search request and its lifecycle."""
    __tablename__ = "search_jobs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    query = Column(String, nullable=False, index=True)
    search_type = Column(String, nullable=False)
    status = Column(String, nullable=False, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)
    error = Column(Text, nullable=True)
    celery_task_id = Column(String, nullable=True, index=True)


class SearchResultRecord(Base):
    """Stores the aggregated result JSON for a completed search job."""
    __tablename__ = "search_results"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    job_id = Column(String, nullable=False, index=True, unique=True)
    query = Column(String, nullable=False)
    result_json = Column(JSON, nullable=False)
    total_profiles = Column(Integer, default=0)
    total_emails = Column(Integer, default=0)
    total_mentions = Column(Integer, default=0)
    overall_confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class ConnectorLog(Base):
    """Per-connector execution log for debugging and audit."""
    __tablename__ = "connector_logs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    job_id = Column(String, nullable=False, index=True)
    connector_name = Column(String, nullable=False)
    status = Column(String, nullable=False)
    duration_ms = Column(Float, nullable=True)
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


# ──────────────────────────────────────────────────────────────
# Dependency / Session factory
# ──────────────────────────────────────────────────────────────

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields a database session."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """Create all tables on startup (use Alembic for prod migrations)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
