"""
DigitalFootprint — Neo4j Identity Graph Layer
==============================================
Manages the identity graph where nodes are identities (emails,
usernames, profiles) and edges represent relationships.

Graph Schema
------------
Nodes:
  - Person      {id, name, confidence}
  - Email       {address}
  - Username    {value, platform}
  - Profile     {url, platform}
  - Domain      {name}

Relationships:
  - (Person)-[:HAS_EMAIL]->(Email)
  - (Person)-[:HAS_USERNAME]->(Username)
  - (Person)-[:HAS_PROFILE]->(Profile)
  - (Username)-[:ON_PLATFORM]->(Domain)
  - (Person)-[:SAME_AS {confidence}]->(Person)
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Optional

from neo4j import AsyncGraphDatabase, AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


class Neo4jDatabase:
    """
    Async Neo4j connection manager.
    Provides high-level graph operations for DigitalFootprint.
    """

    def __init__(self) -> None:
        self._driver = AsyncGraphDatabase.driver(
            settings.NEO4J_URI,
            auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD),
        )

    async def close(self) -> None:
        await self._driver.close()

    async def verify_connectivity(self) -> bool:
        try:
            await self._driver.verify_connectivity()
            return True
        except Exception as e:
            logger.error(f"Neo4j connectivity check failed: {e}")
            return False

    @asynccontextmanager
    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        async with self._driver.session() as session:
            yield session

    # ──────────────────────────────────────────────────────
    # Schema / Constraints
    # ──────────────────────────────────────────────────────

    async def create_constraints(self) -> None:
        """Set up uniqueness constraints on first run."""
        constraints = [
            "CREATE CONSTRAINT IF NOT EXISTS FOR (p:Person) REQUIRE p.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (e:Email) REQUIRE e.address IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (u:Username) REQUIRE (u.value, u.platform) IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (d:Domain) REQUIRE d.name IS UNIQUE",
        ]
        async with self.session() as s:
            for constraint in constraints:
                try:
                    await s.run(constraint)
                except Exception as e:
                    logger.warning(f"Constraint already exists or error: {e}")

    # ──────────────────────────────────────────────────────
    # Person nodes
    # ──────────────────────────────────────────────────────

    async def upsert_person(
        self,
        person_id: str,
        name: Optional[str] = None,
        confidence: float = 0.5,
        job_id: Optional[str] = None,
        **extra: Any,
    ) -> None:
        props = {k: v for k, v in extra.items() if v is not None}
        if name:
            props["name"] = name
        props["confidence"] = confidence
        if job_id:
            props["job_id"] = job_id

        async with self.session() as s:
            await s.run(
                """
                MERGE (p:Person {id: $id})
                SET p += $props
                """,
                id=person_id,
                props=props,
            )

    # ──────────────────────────────────────────────────────
    # Email nodes
    # ──────────────────────────────────────────────────────

    async def link_email(self, person_id: str, email: str) -> None:
        async with self.session() as s:
            await s.run(
                """
                MERGE (e:Email {address: $email})
                WITH e
                MATCH (p:Person {id: $person_id})
                MERGE (p)-[:HAS_EMAIL]->(e)
                """,
                email=email.lower(),
                person_id=person_id,
            )

    # ──────────────────────────────────────────────────────
    # Username nodes
    # ──────────────────────────────────────────────────────

    async def link_username(
        self, person_id: str, username: str, platform: str, url: Optional[str] = None
    ) -> None:
        async with self.session() as s:
            await s.run(
                """
                MERGE (u:Username {value: $username, platform: $platform})
                SET u.url = $url
                WITH u
                MATCH (p:Person {id: $person_id})
                MERGE (p)-[:HAS_USERNAME]->(u)
                """,
                username=username.lower(),
                platform=platform,
                url=url or "",
                person_id=person_id,
            )

    # ──────────────────────────────────────────────────────
    # Profile nodes
    # ──────────────────────────────────────────────────────

    async def link_profile(
        self, person_id: str, url: str, platform: str, metadata: dict | None = None
    ) -> None:
        async with self.session() as s:
            await s.run(
                """
                MERGE (pr:Profile {url: $url})
                SET pr.platform = $platform, pr.metadata = $metadata
                WITH pr
                MATCH (p:Person {id: $person_id})
                MERGE (p)-[:HAS_PROFILE]->(pr)
                """,
                url=url,
                platform=platform,
                metadata=str(metadata or {}),
                person_id=person_id,
            )

    # ──────────────────────────────────────────────────────
    # Identity linking
    # ──────────────────────────────────────────────────────

    async def link_persons(
        self,
        person_id_a: str,
        person_id_b: str,
        relationship: str,
        confidence: float,
        evidence: list[str] | None = None,
    ) -> None:
        async with self.session() as s:
            await s.run(
                """
                MATCH (a:Person {id: $id_a})
                MATCH (b:Person {id: $id_b})
                MERGE (a)-[r:SAME_AS]-(b)
                SET r.confidence = $confidence,
                    r.relationship = $relationship,
                    r.evidence = $evidence
                """,
                id_a=person_id_a,
                id_b=person_id_b,
                confidence=confidence,
                relationship=relationship,
                evidence=evidence or [],
            )

    # ──────────────────────────────────────────────────────
    # Graph retrieval (for frontend visualization)
    # ──────────────────────────────────────────────────────

    async def get_identity_graph(self, job_id: str) -> dict[str, list]:
        """
        Returns nodes and edges for a given job_id search graph.
        Compatible with the D3 / force-graph frontend format.
        """
        async with self.session() as s:
            result = await s.run(
                """
                MATCH (p:Person {job_id: $job_id})
                OPTIONAL MATCH (p)-[r1:HAS_EMAIL]->(e:Email)
                OPTIONAL MATCH (p)-[r2:HAS_USERNAME]->(u:Username)
                OPTIONAL MATCH (p)-[r3:HAS_PROFILE]->(pr:Profile)
                OPTIONAL MATCH (p)-[r4:SAME_AS]-(p2:Person {job_id: $job_id})
                RETURN p, e, u, pr, p2,
                       r1, r2, r3, r4
                """,
                job_id=job_id,
            )
            records = await result.data()

        nodes: dict[str, dict] = {}
        edges: list[dict] = []

        for rec in records:
            person = rec.get("p")
            if person:
                pid = person["id"]
                nodes[pid] = {
                    "id": pid,
                    "label": person.get("name", pid[:8]),
                    "type": "person",
                    "confidence": person.get("confidence", 0.5),
                }

            email = rec.get("e")
            if email:
                eid = f"email:{email['address']}"
                nodes[eid] = {"id": eid, "label": email["address"], "type": "email"}
                if person:
                    edges.append({"source": pid, "target": eid, "label": "HAS_EMAIL"})

            username = rec.get("u")
            if username:
                uid = f"username:{username['platform']}:{username['value']}"
                nodes[uid] = {
                    "id": uid,
                    "label": f"@{username['value']}",
                    "type": "username",
                    "platform": username["platform"],
                }
                if person:
                    edges.append({"source": pid, "target": uid, "label": "HAS_USERNAME"})

            profile = rec.get("pr")
            if profile:
                prid = f"profile:{profile['url']}"
                nodes[prid] = {
                    "id": prid,
                    "label": profile["platform"],
                    "type": "profile",
                    "url": profile["url"],
                }
                if person:
                    edges.append({"source": pid, "target": prid, "label": "HAS_PROFILE"})

            person2 = rec.get("p2")
            if person2 and person:
                edges.append(
                    {
                        "source": pid,
                        "target": person2["id"],
                        "label": "SAME_AS",
                        "confidence": rec.get("r4", {}).get("confidence", 0),
                    }
                )

        return {"nodes": list(nodes.values()), "edges": edges}


# ──────────────────────────────────────────────────────────────
# Singleton
# ──────────────────────────────────────────────────────────────

_neo4j_db: Optional[Neo4jDatabase] = None


def get_neo4j() -> Neo4jDatabase:
    global _neo4j_db
    if _neo4j_db is None:
        _neo4j_db = Neo4jDatabase()
    return _neo4j_db
