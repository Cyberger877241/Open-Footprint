"""
DigitalFootprint — LangChain Agent Tools
==========================================
Wraps each connector as a LangChain Tool so the
orchestrator LLM can decide which ones to call.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from langchain.tools import Tool

from app.connectors import (
    GitHubConnector,
    HaveIBeenPwnedConnector,
    HunterConnector,
    NewsConnector,
    SerpAPIConnector,
    SherlockConnector,
)


def _run_async(coro) -> Any:
    """Run an async coroutine from a sync context (for LangChain compat)."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


# ──────────────────────────────────────────────────────────────
# Individual tool factory functions
# ──────────────────────────────────────────────────────────────

def _make_hibp_tool() -> Tool:
    connector = HaveIBeenPwnedConnector()

    def run(email: str) -> str:
        result = _run_async(connector.run(email))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="check_email_breaches",
        description=(
            "Check if an email address appears in known data breaches. "
            "Input must be a valid email address. "
            "Returns breach names, dates, and compromised data types."
        ),
        func=run,
    )


def _make_hunter_tool() -> Tool:
    connector = HunterConnector()

    def run(query: str) -> str:
        result = _run_async(connector.run(query))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="hunter_email_lookup",
        description=(
            "Look up email intelligence via Hunter.io. "
            "Input: email address to verify, or domain name to find emails. "
            "Returns email verification score, sources, and deliverability info."
        ),
        func=run,
    )


def _make_github_tool() -> Tool:
    connector = GitHubConnector()

    def run(query: str) -> str:
        result = _run_async(connector.run(query))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="github_profile_search",
        description=(
            "Search GitHub for a developer's profile. "
            "Input: GitHub username OR email address. "
            "Returns profile info, repos, commit emails, and programming languages."
        ),
        func=run,
    )


def _make_sherlock_tool() -> Tool:
    connector = SherlockConnector()

    def run(username: str) -> str:
        result = _run_async(connector.run(username))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="username_search",
        description=(
            "Search for a username across 300+ social media platforms and websites. "
            "Input: username (without @ symbol). "
            "Returns list of platforms where the username exists with profile URLs."
        ),
        func=run,
    )


def _make_serpapi_tool() -> Tool:
    connector = SerpAPIConnector()

    def run(query: str) -> str:
        result = _run_async(connector.run(query))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="web_search_mentions",
        description=(
            "Search the web for mentions, articles, and profiles related to a person. "
            "Input: person's name, username, or email address. "
            "Returns Google search results, LinkedIn matches, and Twitter mentions."
        ),
        func=run,
    )


def _make_news_tool() -> Tool:
    connector = NewsConnector()

    def run(query: str) -> str:
        result = _run_async(connector.run(query))
        return json.dumps(result.data or {"error": result.error}, indent=2)

    return Tool(
        name="news_and_content_search",
        description=(
            "Search for news articles, HackerNews discussions, and developer content "
            "mentioning the target. Input: name, username, or email. "
            "Returns news articles, HN threads, and DEV.to posts."
        ),
        func=run,
    )


# ──────────────────────────────────────────────────────────────
# Tool registry
# ──────────────────────────────────────────────────────────────

def get_all_tools() -> list[Tool]:
    """Return all LangChain tools, skipping unavailable connectors."""
    from app.connectors import (
        HaveIBeenPwnedConnector,
        HunterConnector,
        GitHubConnector,
        SherlockConnector,
        SerpAPIConnector,
        NewsConnector,
    )

    tool_factories = [
        (_make_hibp_tool, HaveIBeenPwnedConnector),
        (_make_hunter_tool, HunterConnector),
        (_make_github_tool, GitHubConnector),
        (_make_sherlock_tool, SherlockConnector),
        (_make_serpapi_tool, SerpAPIConnector),
        (_make_news_tool, NewsConnector),
    ]

    tools = []
    for factory, connector_cls in tool_factories:
        instance = connector_cls()
        if instance.is_available():
            tools.append(factory())

    return tools
