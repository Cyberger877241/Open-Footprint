"""
DigitalFootprint — LangChain Orchestrator Agent
================================================
A ReAct-style agent that:
  1. Analyzes the incoming query (name / email / username)
  2. Decides which connectors to invoke (via Tools)
  3. Iterates based on intermediate findings
  4. Returns a structured investigation summary

Falls back to running all available connectors directly if
no LLM key is configured (deterministic mode).
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Optional

from app.config import settings
from app.connectors import get_available_connectors
from app.models.schemas import SearchType

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# System prompt
# ──────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are DigitalFootprint, an OSINT research assistant.
Your job is to investigate a digital identity using publicly available data.

Given a query (email, username, or full name), you must:
1. Identify what type of query it is
2. Call the appropriate tools to gather intelligence
3. Look for cross-references between sources
4. Report findings in a structured way

IMPORTANT RULES:
- Only use publicly available data
- Respect rate limits between API calls
- If a query is a username, always call username_search first
- If a query is an email, always call check_email_breaches first
- Always call news_and_content_search for any query type
- If GitHub username is found, call github_profile_search
- Be thorough but efficient — avoid redundant tool calls

When done, summarize what you found including:
- Confirmed email addresses
- Social media profiles found
- GitHub/developer presence
- News mentions
- Data breach exposure
"""


# ──────────────────────────────────────────────────────────────
# Orchestrator
# ──────────────────────────────────────────────────────────────

class SearchOrchestrator:
    """
    Coordinates connector execution for a search query.

    Two modes:
    - Agent mode (LLM available): LangChain ReAct agent decides tool order
    - Direct mode (no LLM): Runs all available connectors in parallel
    """

    def __init__(self) -> None:
        self._agent = None
        self._agent_initialized = False

    def _init_agent(self) -> Optional[Any]:
        """Lazy-initialize the LangChain agent."""
        if self._agent_initialized:
            return self._agent

        self._agent_initialized = True

        if not settings.has_llm:
            logger.info("No LLM configured — using direct connector mode")
            self._agent = None
            return None

        try:
            from langchain.agents import AgentExecutor, create_react_agent
            from langchain.prompts import PromptTemplate
            from app.agent.tools import get_all_tools

            tools = get_all_tools()
            if not tools:
                logger.warning("No tools available for agent")
                self._agent = None
                return None

            llm = self._build_llm()
            prompt = self._build_prompt(tools)
            agent = create_react_agent(llm, tools, prompt)
            self._agent = AgentExecutor(
                agent=agent,
                tools=tools,
                verbose=settings.DEBUG,
                max_iterations=8,
                handle_parsing_errors=True,
                return_intermediate_steps=True,
            )
            logger.info(f"Agent initialized with {len(tools)} tools")
        except Exception as e:
            logger.error(f"Failed to initialize agent: {e}", exc_info=True)
            self._agent = None

        return self._agent

    def _build_llm(self):
        if settings.LLM_PROVIDER == "openai":
            from langchain_openai import ChatOpenAI
            return ChatOpenAI(
                model=settings.LLM_MODEL,
                temperature=0,
                api_key=settings.OPENAI_API_KEY,
            )
        else:
            from langchain_anthropic import ChatAnthropic
            return ChatAnthropic(
                model="claude-3-haiku-20240307",  # Fast & cheap
                temperature=0,
                api_key=settings.ANTHROPIC_API_KEY,
            )

    def _build_prompt(self, tools):
        from langchain.prompts import PromptTemplate

        tool_names = ", ".join(t.name for t in tools)
        tool_descriptions = "\n".join(
            f"- {t.name}: {t.description}" for t in tools
        )

        template = (
            SYSTEM_PROMPT
            + f"""

Available tools:
{tool_descriptions}

Tool names: {tool_names}

Query: {{input}}

Scratch pad (use this to think step by step):
{{agent_scratchpad}}

Use the following format:
Thought: Think about what to do next
Action: tool_name
Action Input: the input to the tool
Observation: the result
... (repeat as needed)
Thought: I now have enough information
Final Answer: A comprehensive summary of all findings
"""
        )
        return PromptTemplate.from_template(template)

    # ──────────────────────────────────────────────────────
    # Main search method
    # ──────────────────────────────────────────────────────

    async def search(
        self,
        query: str,
        search_type: SearchType,
        include_connectors: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """
        Execute an OSINT search.

        Returns:
            {
                "connector_results": [...],
                "agent_summary": "...",  # if LLM available
                "mode": "agent" | "direct"
            }
        """
        agent = self._init_agent()

        if agent is not None:
            return await self._agent_search(agent, query, search_type, include_connectors)
        else:
            return await self._direct_search(query, search_type, include_connectors)

    async def _agent_search(
        self,
        agent,
        query: str,
        search_type: SearchType,
        include_connectors: Optional[list[str]],
    ) -> dict[str, Any]:
        """Run search via LangChain agent (LLM-guided)."""
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: agent.invoke(
                    {"input": f"Investigate this digital identity: {query} (type: {search_type.value})"}
                ),
            )

            # Extract intermediate tool results
            connector_results = []
            for step in result.get("intermediate_steps", []):
                action, observation = step
                connector_results.append({
                    "connector": action.tool,
                    "status": "success",
                    "data": _safe_parse(observation),
                    "duration_ms": None,
                })

            return {
                "connector_results": connector_results,
                "agent_summary": result.get("output", ""),
                "mode": "agent",
            }
        except Exception as e:
            logger.error(f"Agent search failed, falling back to direct: {e}")
            return await self._direct_search(query, search_type, include_connectors)

    async def _direct_search(
        self,
        query: str,
        search_type: SearchType,
        include_connectors: Optional[list[str]],
    ) -> dict[str, Any]:
        """
        Run all available connectors in parallel (no LLM required).
        This is the deterministic fallback mode.
        """
        connectors = get_available_connectors()

        if include_connectors:
            connectors = [c for c in connectors if c.name in include_connectors]

        if not connectors:
            return {
                "connector_results": [],
                "agent_summary": "No connectors available.",
                "mode": "direct",
            }

        # Determine appropriate query per connector type
        tasks = []
        for connector in connectors:
            adapted_query = self._adapt_query(
                query, search_type, connector.name
            )
            if adapted_query:
                tasks.append(connector.run(adapted_query))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        connector_results = []
        for res in results:
            if isinstance(res, Exception):
                logger.warning(f"Connector error: {res}")
                continue
            connector_results.append({
                "connector": res.connector,
                "status": res.status.value,
                "data": res.data,
                "error": res.error,
                "duration_ms": res.duration_ms,
            })

        return {
            "connector_results": connector_results,
            "agent_summary": None,
            "mode": "direct",
        }

    def _adapt_query(
        self, query: str, search_type: SearchType, connector_name: str
    ) -> Optional[str]:
        """
        Map the search query to the right format for each connector.
        Returns None to skip a connector for an incompatible query type.
        """
        is_email = "@" in query
        is_username = not is_email and " " not in query

        # Email-specific connectors
        if connector_name in ("haveibeenpwned", "hunter"):
            return query if is_email else None

        # Username-specific connectors
        if connector_name == "sherlock":
            return query if is_username else None

        # GitHub works with both username and email
        if connector_name == "github":
            return query  # GitHub handles both

        # General connectors work with anything
        return query


def _safe_parse(text: str) -> dict:
    """Try to parse JSON observation, return as-is if not valid JSON."""
    try:
        return json.loads(text)
    except Exception:
        return {"raw": text}
