"""
DigitalFootprint — API Routes
==============================
POST /search   — Submit a new OSINT search job
GET  /result/{job_id} — Poll for results
GET  /jobs     — List recent jobs
DELETE /jobs/{job_id} — Delete a job and its results
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.postgres import (
    ConnectorLog,
    SearchJob,
    SearchResultRecord,
    get_db,
)
from app.models.schemas import (
    JobStatus,
    SearchJobResponse,
    SearchRequest,
    SearchResult,
    SearchType,
)
from app.tasks.search_tasks import run_full_search

router = APIRouter(prefix="/api/v1", tags=["search"])


# ──────────────────────────────────────────────────────────────
# POST /search
# ──────────────────────────────────────────────────────────────

@router.post(
    "/search",
    response_model=SearchJobResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit a new OSINT search",
    description=(
        "Accepts a query (email, username, or name), creates a search job, "
        "and dispatches async connector tasks. Poll GET /result/{job_id} for results."
    ),
)
async def create_search(
    request: SearchRequest,
    db: AsyncSession = Depends(get_db),
) -> SearchJobResponse:
    # Create job record
    job_id = str(uuid.uuid4())
    job = SearchJob(
        id=job_id,
        query=request.query,
        search_type=request.search_type.value,
        status=JobStatus.PENDING.value,
        created_at=datetime.utcnow(),
    )
    db.add(job)
    await db.commit()

    # Dispatch Celery task
    run_full_search.delay(
        job_id=job_id,
        query=request.query,
        search_type=request.search_type.value,
        include_connectors=request.include_connectors,
    )

    return SearchJobResponse(
        job_id=job_id,
        status=JobStatus.PENDING,
        message=f"Search job created. Poll GET /api/v1/result/{job_id} for results.",
        created_at=job.created_at,
    )


# ──────────────────────────────────────────────────────────────
# GET /result/{job_id}
# ──────────────────────────────────────────────────────────────

@router.get(
    "/result/{job_id}",
    summary="Get search results",
    description=(
        "Returns the current status of a search job. "
        "When status='completed', the full result payload is included."
    ),
)
async def get_result(
    job_id: str,
    db: AsyncSession = Depends(get_db),
) -> dict:
    # Fetch job
    result = await db.execute(select(SearchJob).where(SearchJob.id == job_id))
    job = result.scalar_one_or_none()

    if job is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Job '{job_id}' not found",
        )

    # Pending or running — return status only
    if job.status in (JobStatus.PENDING.value, JobStatus.RUNNING.value):
        return {
            "job_id": job_id,
            "query": job.query,
            "status": job.status,
            "created_at": job.created_at.isoformat() if job.created_at else None,
            "started_at": job.started_at.isoformat() if job.started_at else None,
            "message": "Search in progress...",
        }

    # Failed — return error
    if job.status == JobStatus.FAILED.value:
        return {
            "job_id": job_id,
            "query": job.query,
            "status": job.status,
            "error": job.error,
            "created_at": job.created_at.isoformat() if job.created_at else None,
        }

    # Completed — return full result
    res_result = await db.execute(
        select(SearchResultRecord).where(SearchResultRecord.job_id == job_id)
    )
    result_record = res_result.scalar_one_or_none()

    if result_record is None:
        return {
            "job_id": job_id,
            "query": job.query,
            "status": "completed",
            "message": "Results not yet written — try again in a moment.",
        }

    return result_record.result_json


# ──────────────────────────────────────────────────────────────
# GET /jobs
# ──────────────────────────────────────────────────────────────

@router.get(
    "/jobs",
    summary="List recent search jobs",
)
async def list_jobs(
    limit: int = Query(default=20, ge=1, le=100),
    status_filter: Optional[str] = Query(default=None, alias="status"),
    db: AsyncSession = Depends(get_db),
) -> dict:
    query = select(SearchJob).order_by(desc(SearchJob.created_at)).limit(limit)
    if status_filter:
        query = query.where(SearchJob.status == status_filter)

    result = await db.execute(query)
    jobs = result.scalars().all()

    return {
        "total": len(jobs),
        "jobs": [
            {
                "job_id": j.id,
                "query": j.query,
                "search_type": j.search_type,
                "status": j.status,
                "created_at": j.created_at.isoformat() if j.created_at else None,
                "completed_at": j.completed_at.isoformat() if j.completed_at else None,
                "duration_seconds": j.duration_seconds,
            }
            for j in jobs
        ],
    }


# ──────────────────────────────────────────────────────────────
# DELETE /jobs/{job_id}
# ──────────────────────────────────────────────────────────────

@router.delete(
    "/jobs/{job_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a search job and its results",
)
async def delete_job(
    job_id: str,
    db: AsyncSession = Depends(get_db),
) -> None:
    result = await db.execute(select(SearchJob).where(SearchJob.id == job_id))
    job = result.scalar_one_or_none()

    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found")

    # Delete result record if exists
    res_result = await db.execute(
        select(SearchResultRecord).where(SearchResultRecord.job_id == job_id)
    )
    result_record = res_result.scalar_one_or_none()
    if result_record:
        await db.delete(result_record)

    await db.delete(job)
    await db.commit()


# ──────────────────────────────────────────────────────────────
# GET /connectors
# ──────────────────────────────────────────────────────────────

@router.get(
    "/connectors",
    summary="List all connectors and their availability",
)
async def list_connectors() -> dict:
    from app.connectors import list_connector_info
    return {
        "connectors": list_connector_info(),
    }
