"""
DigitalFootprint — Identity Resolution Engine
==============================================
Aggregates raw connector output into unified identity profiles
with confidence scoring.

Techniques used:
  1. Exact matching    — email/username cross-connector deduplication
  2. Username similarity — Levenshtein + Jaro-Winkler distance
  3. Bio embedding similarity — sentence-transformers cosine similarity
  4. Location/name matching — fuzzy string comparison
  5. Graph clustering — connected components across shared identifiers

Each profile receives an overall confidence score (0.0–1.0).
"""
from __future__ import annotations

import logging
import re
import uuid
from collections import defaultdict
from typing import Any, Optional

import numpy as np

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────
# Lazy-loaded ML models (avoid cold-start penalty)
# ──────────────────────────────────────────────────────────────

_embedding_model = None


def _get_embedding_model():
    global _embedding_model
    if _embedding_model is None:
        from sentence_transformers import SentenceTransformer
        from app.config import settings
        logger.info(f"Loading embedding model: {settings.EMBEDDING_MODEL}")
        _embedding_model = SentenceTransformer(settings.EMBEDDING_MODEL)
    return _embedding_model


# ──────────────────────────────────────────────────────────────
# Core identity resolver
# ──────────────────────────────────────────────────────────────

class IdentityResolver:
    """
    Resolves multiple connector outputs into unified ResolvedProfile objects.

    Usage:
        resolver = IdentityResolver()
        profiles = resolver.resolve(query, connector_results)
    """

    def resolve(
        self,
        query: str,
        connector_results: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """
        Main entry point. Takes raw connector result dicts and
        returns a list of resolved identity profile dicts.
        """
        # Extract structured data from each connector
        extracted = self._extract_all(connector_results)

        # Build identity clusters from shared identifiers
        clusters = self._cluster_identities(extracted)

        # Score and format each cluster
        profiles = []
        for cluster in clusters:
            profile = self._build_profile(query, cluster, extracted)
            profiles.append(profile)

        # Sort by confidence descending
        profiles.sort(key=lambda p: p["confidence_score"], reverse=True)
        return profiles

    # ──────────────────────────────────────────────────────
    # Extraction
    # ──────────────────────────────────────────────────────

    def _extract_all(
        self, connector_results: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Parse each connector's output into a normalized structure."""
        extracted = {
            "emails": set(),
            "usernames": set(),
            "names": set(),
            "locations": set(),
            "bios": [],
            "avatar_urls": [],
            "websites": set(),
            "github": None,
            "hibp": None,
            "hunter": None,
            "sherlock_profiles": [],
            "mentions": [],
            "serp_results": [],
        }

        for result in connector_results:
            name = result.get("connector", "")
            data = result.get("data", {})

            if name == "github" and data.get("found"):
                extracted["github"] = data
                if data.get("email"):
                    extracted["emails"].add(data["email"].lower())
                if data.get("name"):
                    extracted["names"].add(data["name"])
                if data.get("location"):
                    extracted["locations"].add(data["location"])
                if data.get("bio"):
                    extracted["bios"].append(data["bio"])
                if data.get("avatar_url"):
                    extracted["avatar_urls"].append(data["avatar_url"])
                if data.get("blog"):
                    extracted["websites"].add(data["blog"])
                if data.get("twitter_username"):
                    extracted["usernames"].add(data["twitter_username"])
                extracted["usernames"].add(data.get("username", ""))
                for ce in data.get("commit_emails", []):
                    if ce.get("email"):
                        extracted["emails"].add(ce["email"].lower())

            elif name == "haveibeenpwned":
                extracted["hibp"] = data
                if data.get("email"):
                    extracted["emails"].add(data["email"].lower())

            elif name == "hunter":
                extracted["hunter"] = data
                if data.get("email"):
                    extracted["emails"].add(data["email"].lower())

            elif name == "sherlock":
                for profile in data.get("found", []):
                    extracted["sherlock_profiles"].append(profile)

            elif name == "news":
                extracted["mentions"].extend(data.get("all_mentions", []))

            elif name == "serpapi":
                extracted["serp_results"].extend(data.get("results", []))

        # Clean up empty usernames
        extracted["usernames"] = {u for u in extracted["usernames"] if u}

        return extracted

    # ──────────────────────────────────────────────────────
    # Clustering
    # ──────────────────────────────────────────────────────

    def _cluster_identities(
        self, extracted: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """
        Simple connected-components clustering.
        In v1, we produce a single primary cluster (all data
        for the queried identity). Multi-cluster support is
        planned for v2 with graph-based resolution.
        """
        primary = {
            "id": str(uuid.uuid4()),
            "emails": list(extracted["emails"]),
            "usernames": list(extracted["usernames"]),
            "names": list(extracted["names"]),
            "locations": list(extracted["locations"]),
            "bios": extracted["bios"],
            "avatar_urls": extracted["avatar_urls"],
            "websites": list(extracted["websites"]),
        }
        return [primary]

    # ──────────────────────────────────────────────────────
    # Profile building
    # ──────────────────────────────────────────────────────

    def _build_profile(
        self,
        query: str,
        cluster: dict[str, Any],
        extracted: dict[str, Any],
    ) -> dict[str, Any]:
        """Build a ResolvedProfile dict from a cluster."""
        confidence = self._calculate_confidence(cluster, extracted, query)

        # Build social profiles list from Sherlock + other sources
        social_profiles = []
        for sp in extracted["sherlock_profiles"]:
            social_profiles.append({
                "platform": sp.get("platform", ""),
                "username": sp.get("username", query),
                "url": sp.get("url", ""),
                "exists": True,
                "profile_data": {},
            })

        # GitHub profile
        github_data = extracted.get("github")

        # Build mentions object
        mentions = None
        if extracted["mentions"] or extracted["serp_results"]:
            news = [m for m in extracted["mentions"] if m.get("source_type") == "news"]
            web = extracted["serp_results"]
            mentions = {
                "query": query,
                "news_articles": news[:10],
                "web_results": web[:10],
                "total_mentions": len(extracted["mentions"]) + len(extracted["serp_results"]),
            }

        # Email intelligence
        email_intel = []
        if extracted.get("hibp"):
            hibp = extracted["hibp"]
            email_intel.append({
                "email": hibp.get("email", ""),
                "breaches": hibp.get("breaches", []),
                "breach_count": hibp.get("breach_count", 0),
                "hunter_sources": [],
                "hunter_score": extracted.get("hunter", {}).get("score"),
            })

        return {
            "profile_id": cluster["id"],
            "confidence_score": confidence,
            "emails": cluster["emails"],
            "usernames": cluster["usernames"],
            "names": cluster["names"],
            "locations": cluster["locations"],
            "websites": cluster["websites"],
            "github": github_data,
            "email_intel": email_intel,
            "social_profiles": social_profiles,
            "mentions": mentions,
            "identity_links": [],
            "avatar_url": cluster["avatar_urls"][0] if cluster["avatar_urls"] else None,
            "bio": cluster["bios"][0] if cluster["bios"] else None,
            "primary_identity": self._guess_primary_name(cluster),
        }

    def _guess_primary_name(self, cluster: dict) -> Optional[str]:
        """Best-guess at the person's real name."""
        if cluster["names"]:
            # Prefer longer names (more likely real names vs handles)
            return sorted(cluster["names"], key=len, reverse=True)[0]
        if cluster["usernames"]:
            return cluster["usernames"][0]
        return None

    # ──────────────────────────────────────────────────────
    # Confidence scoring
    # ──────────────────────────────────────────────────────

    def _calculate_confidence(
        self,
        cluster: dict[str, Any],
        extracted: dict[str, Any],
        query: str,
    ) -> float:
        """
        Multi-signal confidence score (0.0 – 1.0).

        Signals:
          +0.25 — GitHub profile found & matches query
          +0.20 — Email breach data found (confirms email is real)
          +0.20 — 2+ social profiles found via Sherlock
          +0.15 — News/web mentions found
          +0.10 — Cross-source email match (same email in 2+ connectors)
          +0.10 — Bio embedding similarity > 0.7 across sources
        """
        score = 0.0
        signals = []

        github = extracted.get("github")
        if github and github.get("found"):
            username_match = _username_similarity(
                query, github.get("username", "")
            )
            score += 0.25 * username_match
            signals.append(f"github_match={username_match:.2f}")

        hibp = extracted.get("hibp")
        if hibp and hibp.get("is_compromised"):
            score += 0.20
            signals.append("email_in_breach")
        elif hibp and hibp.get("breach_count") == 0 and hibp.get("email"):
            score += 0.10  # Email exists, just not breached
            signals.append("email_verified_clean")

        sherlock_count = len(extracted.get("sherlock_profiles", []))
        if sherlock_count >= 2:
            score += 0.20
            signals.append(f"sherlock_found={sherlock_count}")
        elif sherlock_count == 1:
            score += 0.10
            signals.append("sherlock_found=1")

        mentions_count = len(extracted.get("mentions", []))
        serp_count = len(extracted.get("serp_results", []))
        if mentions_count + serp_count > 5:
            score += 0.15
            signals.append(f"mentions={mentions_count+serp_count}")
        elif mentions_count + serp_count > 0:
            score += 0.07

        # Cross-source email deduplication bonus
        emails = cluster.get("emails", [])
        if len(emails) > 1:
            score += 0.10
            signals.append(f"cross_source_emails={len(emails)}")

        # Bio embedding similarity (if multiple bios)
        bio_score = self._bio_similarity_score(extracted.get("bios", []))
        if bio_score > 0:
            score += 0.10 * bio_score
            signals.append(f"bio_sim={bio_score:.2f}")

        final_score = min(score, 1.0)
        logger.debug(f"Confidence signals: {signals} → {final_score:.3f}")
        return round(final_score, 3)

    def _bio_similarity_score(self, bios: list[str]) -> float:
        """
        Compute pairwise cosine similarity between bio texts.
        Returns 0.0 if < 2 bios, otherwise average similarity.
        """
        if len(bios) < 2:
            return 0.0
        try:
            model = _get_embedding_model()
            embeddings = model.encode(bios, convert_to_numpy=True)
            # Pairwise cosine similarity
            norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
            normalized = embeddings / (norms + 1e-8)
            sim_matrix = normalized @ normalized.T
            # Average of upper triangle (excluding diagonal)
            n = len(bios)
            total = 0.0
            count = 0
            for i in range(n):
                for j in range(i + 1, n):
                    total += float(sim_matrix[i, j])
                    count += 1
            return total / count if count > 0 else 0.0
        except Exception as e:
            logger.warning(f"Bio similarity failed: {e}")
            return 0.0


# ──────────────────────────────────────────────────────────────
# Utility functions
# ──────────────────────────────────────────────────────────────

def _username_similarity(a: str, b: str) -> float:
    """
    Combined username similarity score using:
      - Exact match (1.0)
      - Case-insensitive match (0.95)
      - Levenshtein ratio
      - Jaro-Winkler distance
    """
    if not a or not b:
        return 0.0
    a, b = a.lower().strip(), b.lower().strip()
    if a == b:
        return 1.0

    try:
        import Levenshtein
        lev = Levenshtein.ratio(a, b)
    except ImportError:
        lev = _simple_ratio(a, b)

    try:
        import jellyfish
        jaro = jellyfish.jaro_winkler_similarity(a, b)
    except ImportError:
        jaro = lev

    return round((lev + jaro) / 2, 3)


def _simple_ratio(a: str, b: str) -> float:
    """Fallback similarity without Levenshtein library."""
    matches = sum(c1 == c2 for c1, c2 in zip(a, b))
    return 2 * matches / (len(a) + len(b)) if (len(a) + len(b)) > 0 else 0.0


# Module-level singleton
_resolver: Optional[IdentityResolver] = None


def get_resolver() -> IdentityResolver:
    global _resolver
    if _resolver is None:
        _resolver = IdentityResolver()
    return _resolver
