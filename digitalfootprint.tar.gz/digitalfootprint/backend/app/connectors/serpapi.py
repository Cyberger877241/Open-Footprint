"""
DigitalFootprint — SerpAPI Connector
======================================
Fetches Google Search results via SerpAPI.

API Docs: https://serpapi.com/search-api
Free tier: 100 searches/month

We use this to find web mentions, cached profiles, and
public content not covered by dedicated APIs.

Queries generated:
  - "{query}" — broad search
  - "{query}" site:linkedin.com — LinkedIn presence
  - "{query}" site:twitter.com OR site:x.com — Twitter/X
  - email:{query} — email-specific results
"""
from __future__ import annotations

from typing import Any

from app.config import settings
from app.connectors.base import BaseConnector

SERPAPI_URL = "https://serpapi.com/search"


class SerpAPIConnector(BaseConnector):
    """
    Google Search results via SerpAPI.

    Required config:
        SERPAPI_KEY — from https://serpapi.com/users/sign_up
    """

    name = "serpapi"
    description = "Google Search results for mentions and profile discovery"
    base_url = "https://serpapi.com"
    required_keys = ["SERPAPI_KEY"]

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Run multiple targeted queries and aggregate results.
        """
        is_email = "@" in query

        tasks = [self._search(query, "general")]
        if not is_email:
            tasks.append(self._search(f'"{query}" site:linkedin.com', "linkedin"))
            tasks.append(self._search(f'"{query}" site:twitter.com OR site:x.com', "twitter"))
            tasks.append(self._search(f'"{query}" site:github.com', "github_web"))
        else:
            tasks.append(self._search(f'email:"{query}"', "email_mentions"))

        results = {}
        for coro in tasks:
            key, data = await coro
            results[key] = data
            await self._throttle(0.5)

        all_results = []
        for key, items in results.items():
            for item in items:
                item["search_type"] = key
                all_results.append(item)

        return {
            "query": query,
            "total_results": len(all_results),
            "results": all_results,
            "by_type": results,
        }

    async def _search(self, q: str, label: str) -> tuple[str, list[dict]]:
        """Execute a single SerpAPI query."""
        try:
            resp = await self._get(
                SERPAPI_URL,
                params={
                    "q": q,
                    "api_key": settings.SERPAPI_KEY,
                    "engine": "google",
                    "num": 10,
                    "hl": "en",
                    "gl": "us",
                    "safe": "active",
                },
            )
            data = resp.json()
            organic = data.get("organic_results", [])

            return label, [
                {
                    "title": r.get("title", ""),
                    "url": r.get("link", ""),
                    "snippet": r.get("snippet", ""),
                    "displayed_link": r.get("displayed_link", ""),
                    "position": r.get("position", 0),
                    "date": r.get("date", ""),
                }
                for r in organic
            ]
        except Exception as e:
            return label, []
