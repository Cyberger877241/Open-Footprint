"""
DigitalFootprint — Connector Registry
=======================================
Central registry for all data source connectors.
Add new connectors here and they'll be auto-discovered
by the orchestrator.
"""
from __future__ import annotations

from app.connectors.base import BaseConnector
from app.connectors.github import GitHubConnector
from app.connectors.haveibeenpwned import HaveIBeenPwnedConnector
from app.connectors.hunter import HunterConnector
from app.connectors.news import NewsConnector
from app.connectors.serpapi import SerpAPIConnector
from app.connectors.sherlock import SherlockConnector

# ──────────────────────────────────────────────────────────────
# All registered connectors
# ──────────────────────────────────────────────────────────────
ALL_CONNECTORS: list[type[BaseConnector]] = [
    HaveIBeenPwnedConnector,
    HunterConnector,
    GitHubConnector,
    SherlockConnector,
    SerpAPIConnector,
    NewsConnector,
]

# Instantiated connector instances (singletons)
_connector_instances: dict[str, BaseConnector] = {}


def get_connector(name: str) -> BaseConnector | None:
    """Get a connector instance by name."""
    if name not in _connector_instances:
        for cls in ALL_CONNECTORS:
            if cls.name == name:
                _connector_instances[name] = cls()
                break
    return _connector_instances.get(name)


def get_all_connectors() -> list[BaseConnector]:
    """Return instances of all registered connectors."""
    instances = []
    for cls in ALL_CONNECTORS:
        if cls.name not in _connector_instances:
            _connector_instances[cls.name] = cls()
        instances.append(_connector_instances[cls.name])
    return instances


def get_available_connectors() -> list[BaseConnector]:
    """Return only connectors with valid configuration."""
    return [c for c in get_all_connectors() if c.is_available()]


def list_connector_info() -> list[dict]:
    """Return metadata about all connectors for the health endpoint."""
    return [
        {
            "name": c.name,
            "description": c.description,
            "available": c.is_available(),
            "required_keys": c.required_keys,
        }
        for c in get_all_connectors()
    ]


__all__ = [
    "ALL_CONNECTORS",
    "BaseConnector",
    "get_connector",
    "get_all_connectors",
    "get_available_connectors",
    "list_connector_info",
    "HaveIBeenPwnedConnector",
    "HunterConnector",
    "GitHubConnector",
    "SherlockConnector",
    "SerpAPIConnector",
    "NewsConnector",
]
