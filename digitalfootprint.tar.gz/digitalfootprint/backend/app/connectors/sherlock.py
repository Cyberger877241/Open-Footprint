"""
DigitalFootprint — Sherlock Username Connector
===============================================
Integrates with the Sherlock open-source tool to search for
a username across 300+ social networks.

Sherlock: https://github.com/sherlock-project/sherlock
License:  MIT

Method:
  We use sherlock's Python API (sherlock_project package)
  rather than shelling out to the CLI, for better async
  compatibility and structured output.

Respects robots.txt and platform TOS — Sherlock itself
only checks publicly accessible profile URLs.
"""
from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from typing import Any

from app.config import settings
from app.connectors.base import BaseConnector


class SherlockConnector(BaseConnector):
    """
    Username existence search across social platforms via Sherlock.

    No API key required — Sherlock sends GET requests to public
    profile URLs and checks response codes / body patterns.
    """

    name = "sherlock"
    description = "Username search across 300+ social platforms"
    required_keys: list[str] = []  # No API key needed

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Args:
            query: Username to search for.

        Returns:
            Dict with 'found' list (platforms where user exists)
            and 'not_found' list.
        """
        username = query.strip().lstrip("@")

        # Run sherlock in a thread pool to avoid blocking the event loop
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, self._run_sherlock, username)
        return result

    def _run_sherlock(self, username: str) -> dict[str, Any]:
        """
        Runs Sherlock via subprocess for reliability.
        Output is JSON-parsed from the --json flag.
        """
        try:
            proc = subprocess.run(
                [
                    sys.executable, "-m", "sherlock",
                    username,
                    "--timeout", str(settings.SHERLOCK_TIMEOUT),
                    "--print-found",
                    "--no-color",
                    "--output", "/tmp/sherlock_output.txt",
                ],
                capture_output=True,
                text=True,
                timeout=settings.SHERLOCK_TIMEOUT * 50,  # overall timeout
            )
            return self._parse_sherlock_output(username, proc.stdout, proc.stderr)
        except subprocess.TimeoutExpired:
            return {
                "username": username,
                "found": [],
                "not_found": [],
                "error": "Sherlock timed out",
            }
        except FileNotFoundError:
            # Try the sherlock_project package directly
            return self._run_sherlock_python(username)
        except Exception as e:
            return {"username": username, "error": str(e), "found": []}

    def _parse_sherlock_output(
        self, username: str, stdout: str, stderr: str
    ) -> dict[str, Any]:
        """Parse Sherlock's stdout text output into structured data."""
        found = []
        not_found = []
        errors = []

        for line in stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            if "[+]" in line:
                # Found: [+] Platform Name: https://platform.com/username
                parts = line.replace("[+]", "").strip().split(":", 1)
                if len(parts) == 2:
                    platform = parts[0].strip()
                    url = parts[1].strip()
                    found.append({"platform": platform, "url": url, "username": username})
            elif "[-]" in line or "[E]" in line:
                pass  # Not found / error — skip

        return {
            "username": username,
            "found": found,
            "not_found_count": len(not_found),
            "total_checked": len(found) + len(not_found),
        }

    def _run_sherlock_python(self, username: str) -> dict[str, Any]:
        """
        Fallback: use sherlock_project Python API directly.
        This is the preferred method when the package is installed.
        """
        try:
            from sherlock_project.sherlock import sherlock, QueryStatus, QueryNotifyPrint
            from sherlock_project.sites import SitesInformation

            sites = SitesInformation()
            site_data = {
                site.name: site.information for site in sites
            }

            notify = QueryNotifyPrint(result=None, verbose=False, print_all=False)

            results = sherlock(
                username,
                site_data,
                query_notify=notify,
                tor=False,
                unique_tor=False,
                proxy=None,
                timeout=settings.SHERLOCK_TIMEOUT,
            )

            found = []
            for site_name, result in results.items():
                if result.get("status") == QueryStatus.CLAIMED:
                    found.append({
                        "platform": site_name,
                        "url": result.get("url_user", ""),
                        "username": username,
                    })

            return {
                "username": username,
                "found": found,
                "total_checked": len(results),
            }

        except ImportError:
            return {
                "username": username,
                "error": (
                    "sherlock-project not installed. "
                    "Run: pip install sherlock-project"
                ),
                "found": [],
            }
        except Exception as e:
            return {"username": username, "error": str(e), "found": []}
