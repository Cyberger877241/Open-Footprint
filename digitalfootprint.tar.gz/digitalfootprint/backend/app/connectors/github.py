"""
DigitalFootprint — GitHub Connector
=====================================
Fetches developer footprint data from the GitHub REST API v3.

API Docs: https://docs.github.com/en/rest
Free tier: 60 req/hr (unauth), 5000 req/hr (with token)

Data collected:
  - Public profile (name, bio, location, company, blog)
  - Public repositories (names, languages, stars, topics)
  - Commit email addresses (via commit author metadata)
  - Organization memberships
  - Contribution languages breakdown
"""
from __future__ import annotations

import asyncio
from typing import Any, Optional

from app.config import settings
from app.connectors.base import BaseConnector

GITHUB_API = "https://api.github.com"


class GitHubConnector(BaseConnector):
    """
    Developer footprint via GitHub REST API.

    Optional config:
        GITHUB_TOKEN — Personal access token (public_repo scope)
                       Greatly increases rate limits (60→5000/hr).
    """

    name = "github"
    description = "Developer profile, repos, commit emails, and language breakdown"
    base_url = "https://github.com"
    required_keys: list[str] = []  # Works without token (rate limited)

    @property
    def _auth_headers(self) -> dict:
        headers = {"Accept": "application/vnd.github+json"}
        if settings.GITHUB_TOKEN:
            headers["Authorization"] = f"Bearer {settings.GITHUB_TOKEN}"
        return headers

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Args:
            query: GitHub username OR email address.

        If email is provided, we attempt to reverse-search via
        GitHub's commit search API (public commits only).
        """
        query = query.strip()

        if "@" in query:
            return await self._search_by_email(query)
        else:
            return await self._fetch_user_profile(query)

    # ──────────────────────────────────────────────────────
    # Profile fetch
    # ──────────────────────────────────────────────────────

    async def _fetch_user_profile(self, username: str) -> dict[str, Any]:
        """Full profile + repos + commit emails for a username."""
        # User profile
        user_resp = await self._get(
            f"{GITHUB_API}/users/{username}",
            headers=self._auth_headers,
        )
        user = user_resp.json()

        if "message" in user:  # Not Found
            return {"username": username, "found": False, "error": user["message"]}

        # Repositories
        repos = await self._fetch_repos(username)
        await asyncio.sleep(0.3)

        # Extract commit emails from recent commits
        commit_emails = await self._extract_commit_emails(username, repos[:5])
        await asyncio.sleep(0.3)

        # Language aggregation
        languages = await self._aggregate_languages(username, repos[:10])

        # Org memberships (public)
        orgs = await self._fetch_orgs(username)

        return {
            "username": username,
            "found": True,
            "id": user.get("id"),
            "name": user.get("name"),
            "bio": user.get("bio"),
            "avatar_url": user.get("avatar_url"),
            "location": user.get("location"),
            "company": user.get("company"),
            "blog": user.get("blog"),
            "email": user.get("email"),  # Only if user made it public
            "twitter_username": user.get("twitter_username"),
            "public_repos": user.get("public_repos", 0),
            "public_gists": user.get("public_gists", 0),
            "followers": user.get("followers", 0),
            "following": user.get("following", 0),
            "created_at": user.get("created_at"),
            "updated_at": user.get("updated_at"),
            "repos": repos,
            "commit_emails": commit_emails,
            "languages": languages,
            "organizations": orgs,
            "profile_url": f"https://github.com/{username}",
        }

    async def _fetch_repos(self, username: str) -> list[dict]:
        """Fetch public repositories sorted by stars."""
        try:
            resp = await self._get(
                f"{GITHUB_API}/users/{username}/repos",
                headers=self._auth_headers,
                params={"sort": "stars", "per_page": 30, "type": "owner"},
            )
            return [
                {
                    "name": r.get("name"),
                    "full_name": r.get("full_name"),
                    "description": r.get("description"),
                    "url": r.get("html_url"),
                    "language": r.get("language"),
                    "stars": r.get("stargazers_count", 0),
                    "forks": r.get("forks_count", 0),
                    "topics": r.get("topics", []),
                    "is_fork": r.get("fork", False),
                    "created_at": r.get("created_at"),
                    "updated_at": r.get("updated_at"),
                    "homepage": r.get("homepage"),
                    "size": r.get("size", 0),
                }
                for r in resp.json()
            ]
        except Exception:
            return []

    async def _extract_commit_emails(
        self, username: str, repos: list[dict]
    ) -> list[dict]:
        """
        Extract email addresses from recent public commits.
        Uses the commits API — only surfaces emails the committer
        made public (no PII beyond what GitHub exposes).
        """
        email_map: dict[str, dict] = {}

        for repo in repos:
            try:
                full_name = repo.get("full_name", "")
                if not full_name:
                    continue

                resp = await self._get(
                    f"{GITHUB_API}/repos/{full_name}/commits",
                    headers=self._auth_headers,
                    params={"author": username, "per_page": 10},
                )
                commits = resp.json()
                if not isinstance(commits, list):
                    continue

                for commit in commits:
                    author = commit.get("commit", {}).get("author", {})
                    email = author.get("email", "")
                    # Skip GitHub's no-reply addresses
                    if email and "noreply" not in email and "@" in email:
                        if email not in email_map:
                            email_map[email] = {
                                "email": email,
                                "name": author.get("name", ""),
                                "commit_count": 0,
                                "repos": [],
                            }
                        email_map[email]["commit_count"] += 1
                        if repo["name"] not in email_map[email]["repos"]:
                            email_map[email]["repos"].append(repo["name"])

                await asyncio.sleep(0.1)
            except Exception:
                continue

        return list(email_map.values())

    async def _aggregate_languages(
        self, username: str, repos: list[dict]
    ) -> dict[str, int]:
        """Aggregate byte counts by language across repos."""
        lang_totals: dict[str, int] = {}

        for repo in repos:
            if repo.get("is_fork"):
                continue
            try:
                full_name = repo.get("full_name", "")
                resp = await self._get(
                    f"{GITHUB_API}/repos/{full_name}/languages",
                    headers=self._auth_headers,
                )
                for lang, bytes_count in resp.json().items():
                    lang_totals[lang] = lang_totals.get(lang, 0) + bytes_count
                await asyncio.sleep(0.1)
            except Exception:
                continue

        # Return top 10 sorted by usage
        return dict(
            sorted(lang_totals.items(), key=lambda x: x[1], reverse=True)[:10]
        )

    async def _fetch_orgs(self, username: str) -> list[dict]:
        """Fetch public organization memberships."""
        try:
            resp = await self._get(
                f"{GITHUB_API}/users/{username}/orgs",
                headers=self._auth_headers,
            )
            return [
                {
                    "login": o.get("login"),
                    "avatar_url": o.get("avatar_url"),
                    "url": f"https://github.com/{o.get('login')}",
                }
                for o in resp.json()
            ]
        except Exception:
            return []

    # ──────────────────────────────────────────────────────
    # Reverse email search
    # ──────────────────────────────────────────────────────

    async def _search_by_email(self, email: str) -> dict[str, Any]:
        """
        Search GitHub commit history for an email address.
        Uses the public search API (no private data exposed).
        """
        try:
            resp = await self._get(
                f"{GITHUB_API}/search/commits",
                headers={
                    **self._auth_headers,
                    "Accept": "application/vnd.github.cloak-preview+json",
                },
                params={"q": f"author-email:{email}", "per_page": 5},
            )
            data = resp.json()
            items = data.get("items", [])

            usernames_found = set()
            repos_found = []

            for item in items:
                author = item.get("author") or {}
                if author.get("login"):
                    usernames_found.add(author["login"])
                repos_found.append(item.get("repository", {}).get("full_name"))

            return {
                "email": email,
                "found_usernames": list(usernames_found),
                "found_in_repos": [r for r in repos_found if r],
                "total_commits": data.get("total_count", 0),
            }
        except Exception as e:
            return {"email": email, "error": str(e)}
