"""
DigitalFootprint — Hunter.io Connector
========================================
Email discovery and verification via Hunter.io API.

API Docs: https://hunter.io/api-documentation
Free tier: 25 searches/month, 50 verifications/month

Endpoints used:
  GET /v2/email-finder       — Find email by name + domain
  GET /v2/email-verifier     — Verify email deliverability
  GET /v2/domain-search      — Find all emails at a domain
"""
from __future__ import annotations

from typing import Any

from app.config import settings
from app.connectors.base import BaseConnector

HUNTER_BASE = "https://api.hunter.io/v2"


class HunterConnector(BaseConnector):
    """
    Email intelligence via Hunter.io.

    Required config:
        HUNTER_API_KEY — from https://hunter.io/users/sign_up
    """

    name = "hunter"
    description = "Email discovery, verification, and source tracking via Hunter.io"
    base_url = "https://hunter.io"
    required_keys = ["HUNTER_API_KEY"]

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Detects query type and calls appropriate Hunter endpoint.

        Args:
            query: Email address OR domain name
        """
        query = query.strip().lower()

        if "@" in query:
            return await self._verify_email(query)
        elif "." in query and " " not in query:
            return await self._domain_search(query)
        else:
            return {"query": query, "message": "Provide an email or domain for Hunter.io"}

    async def _verify_email(self, email: str) -> dict[str, Any]:
        """Verify an email address and fetch source data."""
        resp = await self._get(
            f"{HUNTER_BASE}/email-verifier",
            params={"email": email, "api_key": settings.HUNTER_API_KEY},
        )
        data = resp.json().get("data", {})

        return {
            "email": email,
            "result": data.get("result"),           # "deliverable" / "undeliverable" / "risky"
            "score": data.get("score"),             # 0-100 confidence
            "regexp": data.get("regexp"),
            "gibberish": data.get("gibberish"),
            "disposable": data.get("disposable"),
            "webmail": data.get("webmail"),
            "mx_records": data.get("mx_records"),
            "smtp_server": data.get("smtp_server"),
            "smtp_check": data.get("smtp_check"),
            "sources": _parse_sources(data.get("sources", [])),
        }

    async def _domain_search(self, domain: str) -> dict[str, Any]:
        """Find all publicly known email addresses at a domain."""
        resp = await self._get(
            f"{HUNTER_BASE}/domain-search",
            params={
                "domain": domain,
                "api_key": settings.HUNTER_API_KEY,
                "limit": 10,
            },
        )
        data = resp.json().get("data", {})

        return {
            "domain": domain,
            "organization": data.get("organization"),
            "pattern": data.get("pattern"),
            "webmail": data.get("webmail"),
            "disposable": data.get("disposable"),
            "total_emails": data.get("meta", {}).get("total", 0),
            "emails": [
                {
                    "email": e.get("value"),
                    "type": e.get("type"),
                    "confidence": e.get("confidence"),
                    "first_name": e.get("first_name"),
                    "last_name": e.get("last_name"),
                    "position": e.get("position"),
                    "linkedin": e.get("linkedin"),
                    "twitter": e.get("twitter"),
                }
                for e in data.get("emails", [])
            ],
        }


def _parse_sources(sources: list) -> list[dict]:
    return [
        {
            "domain": s.get("domain"),
            "uri": s.get("uri"),
            "extracted_on": s.get("extracted_on"),
            "last_seen_on": s.get("last_seen_on"),
            "still_on_page": s.get("still_on_page"),
        }
        for s in sources
    ]
