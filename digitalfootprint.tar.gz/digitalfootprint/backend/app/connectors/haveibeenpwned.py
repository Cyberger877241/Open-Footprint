"""
DigitalFootprint — Have I Been Pwned Connector
================================================
Checks email addresses against the HIBP breach database.

API Docs: https://haveibeenpwned.com/API/v3
Free tier: 1 req / 1500ms (rate limited, no key needed for basic)
           API key required for the full breach list endpoint.

Endpoints used:
  GET /breachedaccount/{account}   — List breaches for an email
  GET /pasteaccount/{account}      — Pastes containing the email
"""
from __future__ import annotations

import asyncio
from typing import Any

from app.config import settings
from app.connectors.base import BaseConnector, RateLimitError


class HaveIBeenPwnedConnector(BaseConnector):
    """
    Email breach intelligence via Have I Been Pwned API v3.

    Required config:
        HIBP_API_KEY — from https://haveibeenpwned.com/API/Key
        ($3.50/month, but no key needed for breach count endpoint)
    """

    name = "haveibeenpwned"
    description = "Check email addresses against known data breaches"
    base_url = "https://haveibeenpwned.com"
    required_keys: list[str] = []  # Works without key (limited)

    BREACH_URL = "https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
    PASTE_URL = "https://haveibeenpwned.com/api/v3/pasteaccount/{email}"
    HIBP_DELAY = 1.6  # Must wait 1500ms+ between requests (free tier)

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Args:
            query: Email address to check.
        Returns:
            Dict with 'breaches' list and 'pastes' list.
        """
        email = query.strip().lower()
        headers = {"hibp-api-key": settings.HIBP_API_KEY} if settings.HIBP_API_KEY else {}
        headers["User-Agent"] = "DigitalFootprint-OSINT"

        breaches = await self._fetch_breaches(email, headers)
        await asyncio.sleep(self.HIBP_DELAY)  # Required polite delay
        pastes = await self._fetch_pastes(email, headers)

        return {
            "email": email,
            "breach_count": len(breaches),
            "breaches": breaches,
            "paste_count": len(pastes),
            "pastes": pastes,
            "is_compromised": len(breaches) > 0,
        }

    async def _fetch_breaches(self, email: str, headers: dict) -> list[dict]:
        """Fetch all breach records for an email address."""
        url = self.BREACH_URL.format(email=email)
        try:
            resp = await self._get(
                url,
                headers=headers,
                params={"truncateResponse": "false"},
            )
            raw = resp.json()
            return [
                {
                    "name": b.get("Name", ""),
                    "title": b.get("Title", ""),
                    "domain": b.get("Domain", ""),
                    "breach_date": b.get("BreachDate", ""),
                    "added_date": b.get("AddedDate", ""),
                    "pwn_count": b.get("PwnCount", 0),
                    "description": _strip_html(b.get("Description", "")),
                    "data_classes": b.get("DataClasses", []),
                    "is_verified": b.get("IsVerified", False),
                    "is_sensitive": b.get("IsSensitive", False),
                    "is_spam_list": b.get("IsSpamList", False),
                }
                for b in raw
            ]
        except Exception as e:
            # 404 means no breaches found — that's normal
            if "404" in str(e):
                return []
            raise

    async def _fetch_pastes(self, email: str, headers: dict) -> list[dict]:
        """Fetch paste records — requires API key."""
        if not settings.HIBP_API_KEY:
            return []  # Pastes endpoint requires auth

        url = self.PASTE_URL.format(email=email)
        try:
            resp = await self._get(url, headers=headers)
            raw = resp.json()
            return [
                {
                    "source": p.get("Source", ""),
                    "id": p.get("Id", ""),
                    "title": p.get("Title", ""),
                    "date": p.get("Date", ""),
                    "email_count": p.get("EmailCount", 0),
                }
                for p in raw
            ]
        except Exception as e:
            if "404" in str(e):
                return []
            return []


def _strip_html(text: str) -> str:
    """Minimal HTML stripping for HIBP descriptions."""
    import re
    return re.sub(r"<[^>]+>", "", text).strip()
