"""
DigitalFootprint — Base Connector
===================================
All data source connectors extend BaseConnector.
This ensures a uniform interface, logging, error handling,
and robots.txt compliance across all integrations.
"""
from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx
from robotexclusionrulesparser import RobotExclusionRulesParser

from app.models.schemas import ConnectorResult, ConnectorStatus

logger = logging.getLogger(__name__)

# Shared HTTP client (reused across connectors)
_http_client: Optional[httpx.AsyncClient] = None


def get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": (
                    "DigitalFootprint-OSINT/1.0 "
                    "(https://github.com/your-org/digitalfootprint; "
                    "open-source OSINT research tool)"
                )
            },
            follow_redirects=True,
        )
    return _http_client


class BaseConnector(ABC):
    """
    Abstract base for all DigitalFootprint data connectors.

    Subclasses must implement:
        - name (property)
        - description (property)
        - required_keys (property)  — list of settings keys required
        - _execute(query, **kwargs) — async fetch logic

    The `run()` method wraps _execute() with:
        - availability check
        - robots.txt compliance
        - timing
        - structured error handling
    """

    # Override in subclass
    name: str = "base"
    description: str = ""
    base_url: str = ""        # Used for robots.txt checking
    required_keys: list[str] = []  # Setting attribute names

    def __init__(self) -> None:
        self._robots_cache: dict[str, RobotExclusionRulesParser] = {}

    # ──────────────────────────────────────────────────────
    # Availability
    # ──────────────────────────────────────────────────────

    def is_available(self) -> bool:
        """
        Returns True if all required API keys / config are present.
        Connectors with no required_keys are always available.
        """
        from app.config import settings

        for key in self.required_keys:
            if not getattr(settings, key, None):
                return False
        return True

    # ──────────────────────────────────────────────────────
    # Robots.txt
    # ──────────────────────────────────────────────────────

    async def _fetch_robots(self, base_url: str) -> RobotExclusionRulesParser:
        """Fetch and cache robots.txt for a domain."""
        domain = urlparse(base_url).netloc
        if domain in self._robots_cache:
            return self._robots_cache[domain]

        robots_url = urljoin(base_url, "/robots.txt")
        parser = RobotExclusionRulesParser()
        try:
            client = get_http_client()
            resp = await client.get(robots_url)
            parser.parse(resp.text)
        except Exception:
            pass  # If we can't fetch robots.txt, assume allowed

        self._robots_cache[domain] = parser
        return parser

    async def is_allowed(self, url: str) -> bool:
        """Check if our user-agent is allowed to access the URL."""
        if not self.base_url:
            return True
        robots = await self._fetch_robots(self.base_url)
        return robots.is_allowed("DigitalFootprint-OSINT", url)

    # ──────────────────────────────────────────────────────
    # Core run method
    # ──────────────────────────────────────────────────────

    async def run(self, query: str, **kwargs: Any) -> ConnectorResult:
        """
        Public entry point. Wraps _execute() with availability
        checks, timing, and error handling.
        """
        if not self.is_available():
            logger.info(f"[{self.name}] Skipped — required keys not configured")
            return ConnectorResult(
                connector=self.name,
                status=ConnectorStatus.SKIPPED,
                error=f"Connector {self.name!r} not configured (missing API keys)",
            )

        start = time.perf_counter()
        try:
            logger.info(f"[{self.name}] Running query={query!r}")
            data = await self._execute(query, **kwargs)
            duration_ms = (time.perf_counter() - start) * 1000
            logger.info(f"[{self.name}] Completed in {duration_ms:.1f}ms")
            return ConnectorResult(
                connector=self.name,
                status=ConnectorStatus.SUCCESS,
                data=data,
                duration_ms=duration_ms,
            )
        except RateLimitError as e:
            logger.warning(f"[{self.name}] Rate limited: {e}")
            return ConnectorResult(
                connector=self.name,
                status=ConnectorStatus.RATE_LIMITED,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            logger.error(f"[{self.name}] Failed: {e}", exc_info=True)
            return ConnectorResult(
                connector=self.name,
                status=ConnectorStatus.FAILED,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    @abstractmethod
    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """Connector-specific data fetching logic."""
        ...

    # ──────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────

    async def _get(self, url: str, **kwargs: Any) -> httpx.Response:
        client = get_http_client()
        resp = await client.get(url, **kwargs)
        if resp.status_code == 429:
            raise RateLimitError(f"429 from {url}")
        resp.raise_for_status()
        return resp

    async def _throttle(self, seconds: float = 1.5) -> None:
        """Polite delay between requests."""
        await asyncio.sleep(seconds)


# ──────────────────────────────────────────────────────────────
# Custom exceptions
# ──────────────────────────────────────────────────────────────

class RateLimitError(Exception):
    """Raised when a connector hits a rate limit."""


class ConnectorNotAvailableError(Exception):
    """Raised when a connector is missing required configuration."""
