"""
DigitalFootprint — News & Content Mentions Connector
======================================================
Aggregates news mentions and public content references.

Sources:
  1. NewsAPI.org         — 100 req/day free, news from 80,000+ sources
  2. HackerNews API      — Free, no key needed (Algolia search)
  3. Reddit (Pushshift)  — Public search API (no key needed)
  4. DEV.to API          — Free developer articles search

Respects robots.txt on all scraped domains.
"""
from __future__ import annotations

import asyncio
from typing import Any

from app.config import settings
from app.connectors.base import BaseConnector

NEWS_API_URL = "https://newsapi.org/v2/everything"
HN_API_URL = "https://hn.algolia.com/api/v1/search"
DEVTO_API_URL = "https://dev.to/api/articles"


class NewsConnector(BaseConnector):
    """
    News and content mentions aggregator.

    Optional config:
        NEWS_API_KEY — from https://newsapi.org/register
                       HN and DEV.to work without a key.
    """

    name = "news"
    description = "News articles, HackerNews mentions, and developer content"
    required_keys: list[str] = []  # HN + DEV.to work without keys

    async def _execute(self, query: str, **kwargs: Any) -> dict[str, Any]:
        """
        Fetch mentions from all available sources concurrently.
        """
        tasks = [
            self._search_hackernews(query),
            self._search_devto(query),
        ]
        if settings.NEWS_API_KEY:
            tasks.append(self._search_newsapi(query))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        news_articles = []
        hn_mentions = []
        devto_articles = []

        for res in results:
            if isinstance(res, Exception):
                continue
            source = res.get("source")
            if source == "newsapi":
                news_articles = res.get("articles", [])
            elif source == "hackernews":
                hn_mentions = res.get("hits", [])
            elif source == "devto":
                devto_articles = res.get("articles", [])

        all_mentions = []
        for a in news_articles:
            all_mentions.append({**a, "source_type": "news"})
        for h in hn_mentions:
            all_mentions.append({**h, "source_type": "hackernews"})
        for d in devto_articles:
            all_mentions.append({**d, "source_type": "devto"})

        return {
            "query": query,
            "total_mentions": len(all_mentions),
            "news_articles": news_articles,
            "hackernews": hn_mentions,
            "devto": devto_articles,
            "all_mentions": all_mentions,
        }

    async def _search_newsapi(self, query: str) -> dict[str, Any]:
        """Search NewsAPI.org for mentions."""
        resp = await self._get(
            NEWS_API_URL,
            params={
                "q": f'"{query}"',
                "apiKey": settings.NEWS_API_KEY,
                "sortBy": "relevancy",
                "pageSize": 10,
                "language": "en",
            },
        )
        data = resp.json()
        return {
            "source": "newsapi",
            "total": data.get("totalResults", 0),
            "articles": [
                {
                    "title": a.get("title", ""),
                    "url": a.get("url", ""),
                    "snippet": a.get("description", ""),
                    "published_at": a.get("publishedAt", ""),
                    "source_name": a.get("source", {}).get("name", ""),
                    "author": a.get("author", ""),
                }
                for a in data.get("articles", [])
                if a.get("title") and "[Removed]" not in a.get("title", "")
            ],
        }

    async def _search_hackernews(self, query: str) -> dict[str, Any]:
        """
        Search HackerNews via Algolia API (free, no auth).
        Finds stories and comments mentioning the query.
        """
        resp = await self._get(
            HN_API_URL,
            params={
                "query": query,
                "tags": "(story,comment)",
                "hitsPerPage": 10,
            },
        )
        data = resp.json()
        return {
            "source": "hackernews",
            "hits": [
                {
                    "title": h.get("title") or h.get("comment_text", "")[:100],
                    "url": h.get("url") or f"https://news.ycombinator.com/item?id={h.get('objectID')}",
                    "points": h.get("points", 0),
                    "author": h.get("author", ""),
                    "published_at": h.get("created_at", ""),
                    "comments": h.get("num_comments", 0),
                    "hn_url": f"https://news.ycombinator.com/item?id={h.get('objectID')}",
                }
                for h in data.get("hits", [])
                if h.get("title") or h.get("comment_text")
            ],
        }

    async def _search_devto(self, query: str) -> dict[str, Any]:
        """
        Search DEV.to articles (free API, no key required).
        """
        resp = await self._get(
            DEVTO_API_URL,
            params={"q": query, "per_page": 10},
        )
        articles = resp.json()
        if not isinstance(articles, list):
            return {"source": "devto", "articles": []}

        return {
            "source": "devto",
            "articles": [
                {
                    "title": a.get("title", ""),
                    "url": a.get("url", ""),
                    "snippet": a.get("description", ""),
                    "published_at": a.get("published_at", ""),
                    "author": a.get("user", {}).get("username", ""),
                    "tags": a.get("tag_list", []),
                    "reactions": a.get("public_reactions_count", 0),
                    "comments": a.get("comments_count", 0),
                }
                for a in articles
            ],
        }
