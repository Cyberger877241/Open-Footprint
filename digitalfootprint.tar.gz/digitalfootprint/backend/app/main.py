"""
DigitalFootprint — FastAPI Application
========================================
Main app factory with:
  - CORS middleware
  - Rate limiting
  - Prometheus metrics
  - Structured logging
  - DB initialization on startup
  - Health check endpoint
"""
from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings

# ──────────────────────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────────────────────

structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.stdlib.add_log_level,
        structlog.processors.JSONRenderer(),
    ]
)
logging.basicConfig(level=logging.DEBUG if settings.DEBUG else logging.INFO)
logger = structlog.get_logger()


# ──────────────────────────────────────────────────────────────
# Lifespan (startup / shutdown)
# ──────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown logic."""
    logger.info("DigitalFootprint starting up...")

    # Initialize PostgreSQL tables
    from app.database.postgres import init_db
    await init_db()
    logger.info("PostgreSQL initialized")

    # Initialize Neo4j constraints
    try:
        from app.database.neo4j_db import get_neo4j
        neo4j = get_neo4j()
        await neo4j.create_constraints()
        logger.info("Neo4j constraints created")
    except Exception as e:
        logger.warning(f"Neo4j not available (non-fatal): {e}")

    logger.info(f"Available connectors: {_get_available_connector_names()}")
    logger.info("DigitalFootprint ready")

    yield

    # Shutdown
    logger.info("DigitalFootprint shutting down...")
    from app.connectors.base import _http_client
    if _http_client and not _http_client.is_closed:
        await _http_client.aclose()


def _get_available_connector_names() -> list[str]:
    try:
        from app.connectors import get_available_connectors
        return [c.name for c in get_available_connectors()]
    except Exception:
        return []


# ──────────────────────────────────────────────────────────────
# App factory
# ──────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="DigitalFootprint",
        description=(
            "Open-source OSINT intelligence platform. "
            "Aggregate digital footprints from public data sources."
        ),
        version="1.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # ── CORS ────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request timing middleware ────────────────────────────
    @app.middleware("http")
    async def add_timing_header(request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        duration = (time.perf_counter() - start) * 1000
        response.headers["X-Response-Time-Ms"] = f"{duration:.1f}"
        return response

    # ── Rate limiting middleware (simple in-memory) ──────────
    _request_counts: dict[str, list[float]] = {}

    @app.middleware("http")
    async def rate_limit(request: Request, call_next):
        if request.url.path.startswith("/api/"):
            ip = request.client.host if request.client else "unknown"
            now = time.time()
            window = 60.0  # 1 minute window

            counts = _request_counts.get(ip, [])
            counts = [t for t in counts if now - t < window]

            if len(counts) >= settings.API_RATE_LIMIT:
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={
                        "error": "Rate limit exceeded",
                        "limit": settings.API_RATE_LIMIT,
                        "window_seconds": int(window),
                    },
                )

            counts.append(now)
            _request_counts[ip] = counts

        return await call_next(request)

    # ── Routers ─────────────────────────────────────────────
    from app.api.routes import router as search_router
    app.include_router(search_router)

    # ── Health check ─────────────────────────────────────────
    @app.get("/health", tags=["meta"])
    async def health():
        services = await _check_services()
        return {
            "status": "ok",
            "version": "1.0.0",
            "app": settings.APP_NAME,
            "connectors_available": _get_available_connector_names(),
            "services": services,
        }

    @app.get("/", tags=["meta"])
    async def root():
        return {
            "app": settings.APP_NAME,
            "docs": "/docs",
            "health": "/health",
            "api": "/api/v1",
        }

    return app


async def _check_services() -> dict[str, str]:
    """Ping each backing service and return status."""
    services = {}

    # Redis
    try:
        import redis.asyncio as aioredis
        r = aioredis.from_url(settings.REDIS_URL)
        await r.ping()
        await r.aclose()
        services["redis"] = "ok"
    except Exception as e:
        services["redis"] = f"error: {e}"

    # Postgres
    try:
        from app.database.postgres import engine
        async with engine.connect() as conn:
            await conn.execute(__import__("sqlalchemy").text("SELECT 1"))
        services["postgres"] = "ok"
    except Exception as e:
        services["postgres"] = f"error: {e}"

    # Neo4j
    try:
        from app.database.neo4j_db import get_neo4j
        ok = await get_neo4j().verify_connectivity()
        services["neo4j"] = "ok" if ok else "unavailable"
    except Exception as e:
        services["neo4j"] = f"error: {e}"

    return services


# ──────────────────────────────────────────────────────────────
# App instance
# ──────────────────────────────────────────────────────────────

app = create_app()
