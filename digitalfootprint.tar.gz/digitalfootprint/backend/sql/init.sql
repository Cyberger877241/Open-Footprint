-- ============================================================
-- DigitalFootprint — PostgreSQL Initialization
-- ============================================================
-- This script runs once on first container start.
-- SQLAlchemy handles table creation via init_db() on app startup.
-- This file sets up extensions and any seed data.
-- ============================================================

-- Enable useful extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For fuzzy text search

-- Indexes will be created by SQLAlchemy ORM on startup.
-- This script just ensures the DB is ready.

SELECT 'DigitalFootprint DB initialized' AS status;
