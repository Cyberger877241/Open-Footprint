"""
DigitalFootprint — Identity Resolver Tests
============================================
Tests the confidence scoring, clustering, and profile
building logic without any external API calls.
"""
from __future__ import annotations

import pytest
from unittest.mock import patch

from app.identity.resolver import IdentityResolver, _username_similarity


# ──────────────────────────────────────────────────────────────
# Username similarity
# ──────────────────────────────────────────────────────────────

class TestUsernameSimilarity:
    def test_exact_match(self):
        assert _username_similarity("johndoe", "johndoe") == 1.0

    def test_case_insensitive(self):
        assert _username_similarity("JohnDoe", "johndoe") == 1.0

    def test_similar_usernames(self):
        score = _username_similarity("johndoe", "john_doe")
        assert score > 0.7, f"Expected > 0.7, got {score}"

    def test_different_usernames(self):
        score = _username_similarity("johndoe", "xyzabc123")
        assert score < 0.5, f"Expected < 0.5, got {score}"

    def test_empty_strings(self):
        assert _username_similarity("", "johndoe") == 0.0
        assert _username_similarity("johndoe", "") == 0.0
        assert _username_similarity("", "") == 0.0

    def test_common_variants(self):
        # Common pattern: adding numbers at end
        score = _username_similarity("johndoe", "johndoe99")
        assert score > 0.6

    def test_prefix_match(self):
        score = _username_similarity("john", "johndoe")
        assert score > 0.5


# ──────────────────────────────────────────────────────────────
# Identity resolver
# ──────────────────────────────────────────────────────────────

class TestIdentityResolver:
    def setup_method(self):
        self.resolver = IdentityResolver()

    def _make_connector_results(self, **overrides):
        """Build a realistic set of connector results."""
        base = [
            {
                "connector": "github",
                "status": "success",
                "data": {
                    "username": "johndoe",
                    "name": "John Doe",
                    "bio": "Software engineer | Open source contributor",
                    "avatar_url": "https://avatars.githubusercontent.com/u/1234",
                    "location": "San Francisco, CA",
                    "company": "ACME Corp",
                    "blog": "https://johndoe.dev",
                    "email": "john@johndoe.dev",
                    "twitter_username": "johndoe",
                    "public_repos": 42,
                    "followers": 500,
                    "following": 100,
                    "found": True,
                    "repos": [],
                    "commit_emails": [
                        {"email": "john@johndoe.dev", "commit_count": 150, "repos": ["myproject"]},
                        {"email": "john.doe@gmail.com", "commit_count": 30, "repos": ["old-project"]},
                    ],
                    "languages": {"Python": 80000, "JavaScript": 20000},
                    "organizations": [],
                },
            },
            {
                "connector": "haveibeenpwned",
                "status": "success",
                "data": {
                    "email": "john@johndoe.dev",
                    "breach_count": 2,
                    "is_compromised": True,
                    "breaches": [
                        {
                            "name": "LinkedIn",
                            "domain": "linkedin.com",
                            "breach_date": "2012-05-05",
                            "data_classes": ["Email addresses", "Passwords"],
                            "is_verified": True,
                            "is_sensitive": False,
                        }
                    ],
                    "pastes": [],
                },
            },
            {
                "connector": "sherlock",
                "status": "success",
                "data": {
                    "username": "johndoe",
                    "found": [
                        {"platform": "GitHub",   "url": "https://github.com/johndoe",         "username": "johndoe"},
                        {"platform": "Twitter",  "url": "https://twitter.com/johndoe",        "username": "johndoe"},
                        {"platform": "Reddit",   "url": "https://reddit.com/user/johndoe",    "username": "johndoe"},
                        {"platform": "LinkedIn", "url": "https://linkedin.com/in/johndoe",    "username": "johndoe"},
                        {"platform": "Mastodon", "url": "https://mastodon.social/@johndoe",   "username": "johndoe"},
                    ],
                    "total_checked": 300,
                },
            },
            {
                "connector": "news",
                "status": "success",
                "data": {
                    "total_mentions": 8,
                    "all_mentions": [
                        {"title": "John Doe speaks at PyCon", "url": "https://example.com/1", "source": "tech-blog", "source_type": "news"},
                        {"title": "johndoe releases new library", "url": "https://news.ycombinator.com/item?id=1", "source": "hackernews", "source_type": "hackernews"},
                    ],
                    "news_articles": [],
                    "hackernews": [],
                    "devto": [],
                },
            },
        ]
        for override in overrides.get("replace", []):
            base = [r if r["connector"] != override["connector"] else override for r in base]
        return base

    def test_resolve_returns_profiles(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        assert len(profiles) >= 1

    def test_profile_has_required_fields(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        assert "profile_id" in profile
        assert "confidence_score" in profile
        assert isinstance(profile["confidence_score"], float)
        assert 0.0 <= profile["confidence_score"] <= 1.0
        assert "emails" in profile
        assert "usernames" in profile
        assert "social_profiles" in profile

    def test_emails_aggregated(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        # Should have both commit emails
        assert "john@johndoe.dev" in profile["emails"]
        assert "john.doe@gmail.com" in profile["emails"]

    def test_social_profiles_aggregated(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        # Sherlock found 5 profiles
        assert len(profile["social_profiles"]) == 5

    def test_high_confidence_with_full_data(self):
        """Full data across multiple connectors should yield high confidence."""
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        score = profiles[0]["confidence_score"]
        assert score >= 0.5, f"Expected >= 0.5, got {score}"

    def test_low_confidence_with_minimal_data(self):
        """Minimal data (only news connector) should yield low confidence."""
        results = [
            {
                "connector": "news",
                "status": "success",
                "data": {
                    "total_mentions": 1,
                    "all_mentions": [{"title": "Mention", "url": "https://example.com", "source": "blog", "source_type": "news"}],
                    "news_articles": [],
                    "hackernews": [],
                    "devto": [],
                },
            }
        ]
        profiles = self.resolver.resolve("someone", results)
        if profiles:
            score = profiles[0]["confidence_score"]
            assert score < 0.5, f"Expected < 0.5, got {score}"

    def test_github_data_attached_to_profile(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        assert profile["github"] is not None
        assert profile["github"]["username"] == "johndoe"

    def test_primary_identity_set(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        assert profile["primary_identity"] is not None

    def test_sorted_by_confidence_desc(self):
        """Multiple profiles should be sorted highest confidence first."""
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        scores = [p["confidence_score"] for p in profiles]
        assert scores == sorted(scores, reverse=True)

    def test_empty_connector_results(self):
        """Should handle zero connector results gracefully."""
        profiles = self.resolver.resolve("nobody", [])
        # May return empty list or a low-confidence placeholder
        assert isinstance(profiles, list)

    def test_failed_connectors_skipped(self):
        """FAILED connector results should not crash the resolver."""
        results = self._make_connector_results()
        results.append({
            "connector": "serpapi",
            "status": "failed",
            "data": {},
            "error": "API key not configured",
        })
        profiles = self.resolver.resolve("johndoe", results)
        assert len(profiles) >= 1  # Should still work

    def test_bio_extracted(self):
        results = self._make_connector_results()
        profiles = self.resolver.resolve("johndoe", results)
        profile = profiles[0]
        assert profile.get("bio") is not None
        assert "engineer" in profile["bio"].lower() or len(profile["bio"]) > 0
