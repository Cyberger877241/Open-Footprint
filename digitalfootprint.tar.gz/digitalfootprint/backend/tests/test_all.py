"""
DigitalFootprint — Test Suite
==============================
Run with:  pytest backend/tests/ -v
"""
from __future__ import annotations

import json
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

# ──────────────────────────────────────────────────────────────
# Connector unit tests
# ──────────────────────────────────────────────────────────────

class TestBaseConnector:
    """Tests for the BaseConnector availability and error handling."""

    def test_connector_unavailable_when_missing_key(self):
        from app.connectors.haveibeenpwned import HaveIBeenPwnedConnector
        c = HaveIBeenPwnedConnector()
        # HIBP has no required keys — always available
        assert c.is_available() is True

    def test_hunter_unavailable_without_key(self, monkeypatch):
        monkeypatch.setattr("app.config.settings.HUNTER_API_KEY", None)
        from app.connectors.hunter import HunterConnector
        c = HunterConnector()
        assert c.is_available() is False

    def test_connector_returns_skipped_when_unavailable(self):
        from app.connectors.hunter import HunterConnector
        from app.models.schemas import ConnectorStatus
        import asyncio

        with patch.object(HunterConnector, "is_available", return_value=False):
            c = HunterConnector()
            result = asyncio.run(c.run("test@example.com"))
            assert result.status == ConnectorStatus.SKIPPED

    @pytest.mark.asyncio
    async def test_connector_wraps_exception_as_failed(self):
        from app.connectors.github import GitHubConnector
        from app.models.schemas import ConnectorStatus

        c = GitHubConnector()
        with patch.object(c, "_execute", side_effect=Exception("network error")):
            result = await c.run("testuser")
            assert result.status == ConnectorStatus.FAILED
            assert "network error" in result.error


class TestHIBPConnector:
    """Have I Been Pwned connector tests."""

    @pytest.mark.asyncio
    async def test_no_breaches_returns_empty(self):
        from app.connectors.haveibeenpwned import HaveIBeenPwnedConnector

        c = HaveIBeenPwnedConnector()
        mock_resp = MagicMock()
        mock_resp.json.return_value = []
        mock_resp.raise_for_status = MagicMock()
        mock_resp.status_code = 200

        with patch.object(c, "_get", AsyncMock(return_value=mock_resp)):
            with patch.object(c, "_throttle", AsyncMock()):
                result = await c._execute("clean@example.com")

        assert result["breach_count"] == 0
        assert result["is_compromised"] is False

    @pytest.mark.asyncio
    async def test_breach_parsing(self):
        from app.connectors.haveibeenpwned import HaveIBeenPwnedConnector

        c = HaveIBeenPwnedConnector()
        mock_resp = MagicMock()
        mock_resp.json.return_value = [
            {
                "Name": "Adobe",
                "Title": "Adobe",
                "Domain": "adobe.com",
                "BreachDate": "2013-10-04",
                "PwnCount": 152445165,
                "Description": "In October 2013...",
                "DataClasses": ["Email addresses", "Passwords"],
                "IsVerified": True,
                "IsSensitive": False,
            }
        ]
        mock_resp.raise_for_status = MagicMock()

        with patch.object(c, "_get", AsyncMock(return_value=mock_resp)):
            with patch.object(c, "_throttle", AsyncMock()):
                result = await c._execute("pwned@example.com")

        assert result["breach_count"] == 1
        assert result["is_compromised"] is True
        assert result["breaches"][0]["name"] == "Adobe"
        assert "Email addresses" in result["breaches"][0]["data_classes"]


class TestGitHubConnector:
    """GitHub connector tests."""

    @pytest.mark.asyncio
    async def test_user_not_found(self):
        from app.connectors.github import GitHubConnector

        c = GitHubConnector()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"message": "Not Found"}
        mock_resp.raise_for_status = MagicMock()

        with patch.object(c, "_get", AsyncMock(return_value=mock_resp)):
            result = await c._execute("nonexistent_user_xyz_123")

        assert result["found"] is False

    @pytest.mark.asyncio
    async def test_user_found_structure(self):
        from app.connectors.github import GitHubConnector

        c = GitHubConnector()
        profile_resp = MagicMock()
        profile_resp.json.return_value = {
            "login": "octocat",
            "name": "The Octocat",
            "bio": "GitHub mascot",
            "location": "San Francisco, CA",
            "public_repos": 8,
            "followers": 9999,
            "following": 9,
            "email": None,
            "avatar_url": "https://github.com/images/error/octocat_happy.gif",
            "created_at": "2011-01-25T18:44:36Z",
            "updated_at": "2022-01-01T00:00:00Z",
        }

        repos_resp = MagicMock()
        repos_resp.json.return_value = []

        orgs_resp = MagicMock()
        orgs_resp.json.return_value = []

        call_count = 0
        async def mock_get(url, **kwargs):
            nonlocal call_count
            call_count += 1
            if "users/octocat/repos" in url:
                return repos_resp
            if "users/octocat/orgs" in url:
                return orgs_resp
            return profile_resp

        with patch.object(c, "_get", side_effect=mock_get):
            result = await c._execute("octocat")

        assert result["found"] is True
        assert result["username"] == "octocat"
        assert result["name"] == "The Octocat"


# ──────────────────────────────────────────────────────────────
# Identity resolver tests
# ──────────────────────────────────────────────────────────────

class TestIdentityResolver:
    """Tests for the identity resolution + confidence scoring engine."""

    def _make_github_result(self, username="testuser", email=None):
        return {
            "connector": "github",
            "status": "success",
            "data": {
                "found": True,
                "username": username,
                "name": "Test User",
                "bio": "Software engineer building cool things",
                "location": "New York, NY",
                "email": email,
                "avatar_url": "https://avatars.githubusercontent.com/u/1",
                "public_repos": 20,
                "followers": 150,
                "following": 50,
                "repos": [],
                "commit_emails": [],
                "languages": {"Python": 50000, "JavaScript": 30000},
                "organizations": [],
            },
        }

    def _make_hibp_result(self, email="test@example.com", breaches=None):
        return {
            "connector": "haveibeenpwned",
            "status": "success",
            "data": {
                "email": email,
                "breach_count": len(breaches or []),
                "breaches": breaches or [],
                "is_compromised": len(breaches or []) > 0,
            },
        }

    def test_resolve_with_github(self):
        from app.identity.resolver import IdentityResolver

        resolver = IdentityResolver()
        results = resolver.resolve(
            "testuser",
            [self._make_github_result("testuser")]
        )

        assert len(results) == 1
        assert results[0]["confidence_score"] > 0
        assert "testuser" in results[0]["usernames"]
        assert results[0]["github"] is not None

    def test_email_extracted_from_github(self):
        from app.identity.resolver import IdentityResolver

        resolver = IdentityResolver()
        results = resolver.resolve(
            "testuser",
            [self._make_github_result("testuser", email="test@example.com")]
        )

        assert "test@example.com" in results[0]["emails"]

    def test_breach_lowers_confidence_threshold(self):
        from app.identity.resolver import IdentityResolver

        resolver = IdentityResolver()
        clean = resolver.resolve("test@example.com", [self._make_hibp_result()])
        breached = resolver.resolve(
            "test@example.com",
            [self._make_hibp_result(breaches=[{"name": "Adobe", "data_classes": ["Passwords"]}])]
        )
        # A breached email should have HIGHER confidence (more evidence)
        assert breached[0]["confidence_score"] >= clean[0]["confidence_score"]

    def test_confidence_capped_at_1(self):
        from app.identity.resolver import IdentityResolver

        resolver = IdentityResolver()
        results = resolver.resolve(
            "testuser",
            [
                self._make_github_result("testuser", email="test@example.com"),
                self._make_hibp_result(email="test@example.com", breaches=[{"name": "Adobe"}]),
                {"connector": "sherlock", "status": "success",
                 "data": {"username": "testuser", "found": [
                     {"platform": "Twitter", "url": "https://twitter.com/testuser"},
                     {"platform": "Reddit",  "url": "https://reddit.com/u/testuser"},
                     {"platform": "Instagram", "url": "https://instagram.com/testuser"},
                 ]}},
                {"connector": "news", "status": "success",
                 "data": {"all_mentions": [{"title": "Test"} for _ in range(10)]}},
            ]
        )

        assert results[0]["confidence_score"] <= 1.0

    def test_username_similarity_exact(self):
        from app.identity.resolver import _username_similarity
        assert _username_similarity("johndoe", "johndoe") == 1.0

    def test_username_similarity_partial(self):
        from app.identity.resolver import _username_similarity
        score = _username_similarity("johndoe", "john_doe")
        assert 0.5 < score < 1.0

    def test_username_similarity_empty(self):
        from app.identity.resolver import _username_similarity
        assert _username_similarity("", "johndoe") == 0.0


# ──────────────────────────────────────────────────────────────
# API endpoint tests
# ──────────────────────────────────────────────────────────────

class TestAPIEndpoints:
    """Integration tests for FastAPI endpoints."""

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient
        from app.main import app
        with TestClient(app) as c:
            yield c

    def test_health_endpoint(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_root_endpoint(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "docs" in resp.json()

    def test_connectors_endpoint(self, client):
        resp = client.get("/api/v1/connectors")
        assert resp.status_code == 200
        data = resp.json()
        assert "connectors" in data
        assert len(data["connectors"]) > 0

    def test_search_returns_job_id(self, client):
        with patch("app.tasks.search_tasks.run_full_search.delay") as mock_task:
            mock_task.return_value = MagicMock()
            resp = client.post(
                "/api/v1/search",
                json={"query": "testuser", "search_type": "username"},
            )
        assert resp.status_code == 202
        data = resp.json()
        assert "job_id" in data
        assert data["status"] == "pending"

    def test_result_not_found(self, client):
        resp = client.get("/api/v1/result/nonexistent-job-id-xyz")
        assert resp.status_code == 404

    def test_rate_limit_enforced(self, client):
        with patch("app.config.settings.API_RATE_LIMIT", 2):
            with patch("app.tasks.search_tasks.run_full_search.delay"):
                for _ in range(2):
                    client.post("/api/v1/search", json={"query": "test"})
                # This should be rate limited now... but in-memory rate limiter
                # resets per client instance in tests, so just verify the
                # endpoint is reachable
                resp = client.get("/api/v1/jobs")
                assert resp.status_code in (200, 429)


# ──────────────────────────────────────────────────────────────
# Sherlock connector tests
# ──────────────────────────────────────────────────────────────

class TestSherlockConnector:
    """Sherlock output parsing tests (no network calls)."""

    def test_parse_stdout_found(self):
        from app.connectors.sherlock import SherlockConnector

        c = SherlockConnector()
        stdout = """[+] Twitter: https://twitter.com/johndoe
[+] GitHub: https://github.com/johndoe
[-] Facebook: Not Found"""

        result = c._parse_sherlock_output("johndoe", stdout, "")
        assert result["username"] == "johndoe"
        assert len(result["found"]) == 2
        urls = [p["url"] for p in result["found"]]
        assert "https://twitter.com/johndoe" in urls
        assert "https://github.com/johndoe" in urls

    def test_parse_stdout_none_found(self):
        from app.connectors.sherlock import SherlockConnector

        c = SherlockConnector()
        result = c._parse_sherlock_output("nobody_xyz_12345", "", "")
        assert result["found"] == []


# ──────────────────────────────────────────────────────────────
# News connector tests
# ──────────────────────────────────────────────────────────────

class TestNewsConnector:
    """News + HackerNews connector tests."""

    @pytest.mark.asyncio
    async def test_hackernews_search(self):
        from app.connectors.news import NewsConnector

        c = NewsConnector()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "hits": [
                {
                    "objectID": "12345",
                    "title": "Interesting post about testuser",
                    "url": "https://example.com/post",
                    "points": 42,
                    "author": "someone",
                    "created_at": "2024-01-01T00:00:00Z",
                    "num_comments": 10,
                }
            ]
        }

        with patch.object(c, "_get", AsyncMock(return_value=mock_resp)):
            result = await c._search_hackernews("testuser")

        assert result["source"] == "hackernews"
        assert len(result["hits"]) == 1
        assert result["hits"][0]["title"] == "Interesting post about testuser"


# ──────────────────────────────────────────────────────────────
# Connector registry tests
# ──────────────────────────────────────────────────────────────

class TestConnectorRegistry:
    def test_all_connectors_registered(self):
        from app.connectors import ALL_CONNECTORS
        names = [c.name for c in ALL_CONNECTORS]
        assert "haveibeenpwned" in names
        assert "github" in names
        assert "sherlock" in names
        assert "serpapi" in names
        assert "news" in names
        assert "hunter" in names

    def test_get_connector_by_name(self):
        from app.connectors import get_connector
        c = get_connector("github")
        assert c is not None
        assert c.name == "github"

    def test_get_unknown_connector_returns_none(self):
        from app.connectors import get_connector
        assert get_connector("nonexistent_connector") is None

    def test_list_connector_info_structure(self):
        from app.connectors import list_connector_info
        info = list_connector_info()
        for item in info:
            assert "name" in item
            assert "description" in item
            assert "available" in item
            assert isinstance(item["available"], bool)
