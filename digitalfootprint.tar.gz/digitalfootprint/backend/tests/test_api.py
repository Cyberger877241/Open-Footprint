"""
DigitalFootprint — API Integration Tests
==========================================
Tests FastAPI routes with a test client.
Database calls are mocked to avoid needing Postgres/Redis.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


# ──────────────────────────────────────────────────────────────
# Health endpoint
# ──────────────────────────────────────────────────────────────

class TestHealth:
    def test_health_returns_200(self, client):
        with patch("app.main._check_services", return_value={"redis": "ok", "postgres": "ok", "neo4j": "ok"}):
            resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_root_returns_docs_link(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "/docs" in resp.json()["docs"]


# ──────────────────────────────────────────────────────────────
# POST /search
# ──────────────────────────────────────────────────────────────

class TestSearchEndpoint:
    @patch("app.api.routes.run_full_search")
    @patch("app.api.routes.get_db")
    def test_post_search_returns_202(self, mock_get_db, mock_task, client):
        # Mock DB session
        mock_session = AsyncMock()
        mock_session.__aenter__ = AsyncMock(return_value=mock_session)
        mock_session.__aexit__ = AsyncMock(return_value=None)
        mock_session.add = MagicMock()
        mock_session.commit = AsyncMock()

        mock_get_db.return_value = mock_session

        # Mock Celery task
        mock_task.delay = MagicMock(return_value=MagicMock(id="celery-task-123"))

        resp = client.post(
            "/api/v1/search",
            json={"query": "johndoe", "search_type": "username"},
        )
        assert resp.status_code in (200, 202, 422)  # 422 if DB mock fails

    def test_search_requires_query(self, client):
        resp = client.post("/api/v1/search", json={})
        assert resp.status_code == 422  # Validation error

    def test_search_invalid_type(self, client):
        resp = client.post(
            "/api/v1/search",
            json={"query": "test", "search_type": "INVALID_TYPE"},
        )
        assert resp.status_code == 422


# ──────────────────────────────────────────────────────────────
# Request schema validation
# ──────────────────────────────────────────────────────────────

class TestSchemaValidation:
    def test_valid_email_query(self, client):
        """Valid email should pass schema validation."""
        from app.models.schemas import SearchRequest, SearchType
        req = SearchRequest(query="test@example.com", search_type=SearchType.EMAIL)
        assert req.query == "test@example.com"

    def test_valid_username_query(self):
        from app.models.schemas import SearchRequest, SearchType
        req = SearchRequest(query="johndoe", search_type=SearchType.USERNAME)
        assert req.search_type == SearchType.USERNAME

    def test_max_depth_bounds(self):
        from app.models.schemas import SearchRequest
        import pydantic
        with pytest.raises(pydantic.ValidationError):
            SearchRequest(query="test", max_depth=10)  # max is 3

    def test_connector_allowlist(self):
        from app.models.schemas import SearchRequest
        req = SearchRequest(
            query="test",
            include_connectors=["github", "haveibeenpwned"],
        )
        assert "github" in req.include_connectors


# ──────────────────────────────────────────────────────────────
# Connector info endpoint
# ──────────────────────────────────────────────────────────────

class TestConnectorsEndpoint:
    def test_connectors_list(self, client):
        resp = client.get("/api/v1/connectors")
        assert resp.status_code == 200
        data = resp.json()
        assert "connectors" in data
        assert isinstance(data["connectors"], list)
        # Should list all 6 connectors
        names = [c["name"] for c in data["connectors"]]
        assert "github" in names
        assert "haveibeenpwned" in names
        assert "sherlock" in names

    def test_connector_has_availability_field(self, client):
        resp = client.get("/api/v1/connectors")
        connectors = resp.json()["connectors"]
        for connector in connectors:
            assert "available" in connector
            assert "name" in connector
            assert "description" in connector
