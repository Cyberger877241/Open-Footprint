"""
DigitalFootprint — Connector Unit Tests
=========================================
All external HTTP calls are mocked — no real API keys needed.
Run: pytest tests/test_connectors.py -v
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.connectors.haveibeenpwned import HaveIBeenPwnedConnector
from app.connectors.github import GitHubConnector
from app.connectors.hunter import HunterConnector
from app.connectors.news import NewsConnector
from app.connectors.serpapi import SerpAPIConnector
from app.connectors.sherlock import SherlockConnector
from app.models.schemas import ConnectorStatus


# ──────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────

def make_response(data: dict | list, status_code: int = 200):
    """Create a mock httpx.Response."""
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = data
    mock.text = json.dumps(data)
    mock.raise_for_status = MagicMock()
    return mock


# ──────────────────────────────────────────────────────────────
# Have I Been Pwned
# ──────────────────────────────────────────────────────────────

class TestHIBPConnector:
    BREACH_DATA = [
        {
            "Name": "TestBreach",
            "Title": "Test Breach 2023",
            "Domain": "test.com",
            "BreachDate": "2023-01-01",
            "AddedDate": "2023-02-01",
            "PwnCount": 500000,
            "Description": "A test breach",
            "DataClasses": ["Email addresses", "Passwords"],
            "IsVerified": True,
            "IsSensitive": False,
            "IsSpamList": False,
        }
    ]

    @pytest.mark.asyncio
    async def test_email_with_breach(self):
        connector = HaveIBeenPwnedConnector()
        mock_resp = make_response(self.BREACH_DATA)

        with patch.object(connector, "_get", return_value=mock_resp), \
             patch("asyncio.sleep", return_value=None):
            result = await connector.run("victim@example.com")

        assert result.status == ConnectorStatus.SUCCESS
        assert result.data["breach_count"] == 1
        assert result.data["is_compromised"] is True
        assert result.data["breaches"][0]["name"] == "TestBreach"
        assert "Passwords" in result.data["breaches"][0]["data_classes"]

    @pytest.mark.asyncio
    async def test_email_no_breach(self):
        connector = HaveIBeenPwnedConnector()
        # 404 = no breaches found (normal HIBP behavior)
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_resp.raise_for_status.side_effect = Exception("404 Not Found")

        with patch.object(connector, "_get", side_effect=Exception("404 Not Found")), \
             patch("asyncio.sleep", return_value=None):
            result = await connector.run("clean@example.com")

        # Should succeed with empty breach list
        assert result.status == ConnectorStatus.SUCCESS
        assert result.data["breach_count"] == 0
        assert result.data["is_compromised"] is False

    @pytest.mark.asyncio
    async def test_invalid_email_format(self):
        connector = HaveIBeenPwnedConnector()
        with patch.object(connector, "_get", side_effect=Exception("400")), \
             patch("asyncio.sleep", return_value=None):
            result = await connector.run("not-an-email")
        assert result.status in (ConnectorStatus.FAILED, ConnectorStatus.SUCCESS)


# ──────────────────────────────────────────────────────────────
# GitHub
# ──────────────────────────────────────────────────────────────

class TestGitHubConnector:
    USER_DATA = {
        "login": "octocat",
        "id": 1,
        "name": "The Octocat",
        "bio": "GitHub mascot",
        "avatar_url": "https://avatars.githubusercontent.com/u/583231",
        "location": "San Francisco, CA",
        "company": "@github",
        "blog": "https://github.blog",
        "email": None,
        "twitter_username": "github",
        "public_repos": 8,
        "public_gists": 8,
        "followers": 10000,
        "following": 9,
        "created_at": "2011-01-25T18:44:36Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }

    REPOS_DATA = [
        {
            "name": "Hello-World",
            "full_name": "octocat/Hello-World",
            "description": "My first repository",
            "html_url": "https://github.com/octocat/Hello-World",
            "language": "Python",
            "stargazers_count": 2000,
            "forks_count": 500,
            "topics": ["beginner", "tutorial"],
            "fork": False,
            "created_at": "2011-01-26T19:01:12Z",
            "updated_at": "2024-01-01T00:00:00Z",
            "homepage": "",
            "size": 108,
        }
    ]

    @pytest.mark.asyncio
    async def test_fetch_user_profile(self):
        connector = GitHubConnector()
        responses = iter([
            make_response(self.USER_DATA),
            make_response(self.REPOS_DATA),
            make_response([]),   # commits
            make_response({}),   # languages
            make_response([]),   # orgs
        ])

        with patch.object(connector, "_get", side_effect=lambda *a, **kw: next(responses)), \
             patch("asyncio.sleep", return_value=None):
            result = await connector.run("octocat")

        assert result.status == ConnectorStatus.SUCCESS
        assert result.data["username"] == "octocat"
        assert result.data["name"] == "The Octocat"
        assert result.data["found"] is True
        assert result.data["followers"] == 10000
        assert len(result.data["repos"]) == 1
        assert result.data["repos"][0]["stars"] == 2000

    @pytest.mark.asyncio
    async def test_user_not_found(self):
        connector = GitHubConnector()
        not_found = make_response({"message": "Not Found"}, 404)

        with patch.object(connector, "_get", return_value=not_found):
            result = await connector.run("this-user-does-not-exist-xyz123")

        assert result.status == ConnectorStatus.SUCCESS
        assert result.data["found"] is False

    @pytest.mark.asyncio
    async def test_search_by_email(self):
        connector = GitHubConnector()
        commit_search = make_response({
            "total_count": 3,
            "items": [
                {
                    "author": {"login": "octocat"},
                    "repository": {"full_name": "octocat/Hello-World"},
                }
            ],
        })

        with patch.object(connector, "_get", return_value=commit_search):
            result = await connector.run("octocat@github.com")

        assert result.status == ConnectorStatus.SUCCESS
        assert "octocat" in result.data.get("found_usernames", [])


# ──────────────────────────────────────────────────────────────
# Hunter.io
# ──────────────────────────────────────────────────────────────

class TestHunterConnector:
    @pytest.mark.asyncio
    async def test_email_verification(self):
        connector = HunterConnector()
        # Patch settings so is_available() returns True
        with patch("app.connectors.hunter.settings") as mock_settings:
            mock_settings.HUNTER_API_KEY = "test-key"
            connector.required_keys = []

            mock_resp = make_response({
                "data": {
                    "result": "deliverable",
                    "score": 92,
                    "regexp": True,
                    "gibberish": False,
                    "disposable": False,
                    "webmail": False,
                    "mx_records": True,
                    "smtp_server": True,
                    "smtp_check": True,
                    "sources": [
                        {
                            "domain": "github.com",
                            "uri": "https://github.com",
                            "extracted_on": "2023-01-01",
                            "last_seen_on": "2024-01-01",
                            "still_on_page": True,
                        }
                    ],
                }
            })

            with patch.object(connector, "_get", return_value=mock_resp):
                result = await connector._execute("test@example.com")

        assert result["result"] == "deliverable"
        assert result["score"] == 92
        assert len(result["sources"]) == 1

    @pytest.mark.asyncio
    async def test_domain_search(self):
        connector = HunterConnector()
        with patch("app.connectors.hunter.settings") as mock_settings:
            mock_settings.HUNTER_API_KEY = "test-key"

            mock_resp = make_response({
                "data": {
                    "organization": "Example Corp",
                    "pattern": "{first}@{domain}",
                    "webmail": False,
                    "disposable": False,
                    "meta": {"total": 42},
                    "emails": [
                        {
                            "value": "john@example.com",
                            "type": "personal",
                            "confidence": 94,
                            "first_name": "John",
                            "last_name": "Doe",
                            "position": "CEO",
                            "linkedin": None,
                            "twitter": None,
                        }
                    ],
                }
            })

            with patch.object(connector, "_get", return_value=mock_resp):
                result = await connector._execute("example.com")

        assert result["organization"] == "Example Corp"
        assert result["total_emails"] == 42
        assert result["emails"][0]["email"] == "john@example.com"


# ──────────────────────────────────────────────────────────────
# News / Content
# ──────────────────────────────────────────────────────────────

class TestNewsConnector:
    @pytest.mark.asyncio
    async def test_hackernews_search(self):
        connector = NewsConnector()
        hn_resp = make_response({
            "hits": [
                {
                    "title": "Show HN: My cool project",
                    "url": "https://example.com/project",
                    "points": 100,
                    "author": "johndoe",
                    "created_at": "2024-01-01T00:00:00.000Z",
                    "num_comments": 42,
                    "objectID": "12345678",
                }
            ]
        })
        devto_resp = make_response([])

        with patch.object(connector, "_get", side_effect=[hn_resp, devto_resp]):
            result = await connector.run("johndoe")

        assert result.status == ConnectorStatus.SUCCESS
        assert len(result.data["hackernews"]) == 1
        assert result.data["hackernews"][0]["author"] == "johndoe"
        assert result.data["total_mentions"] >= 1


# ──────────────────────────────────────────────────────────────
# SerpAPI
# ──────────────────────────────────────────────────────────────

class TestSerpAPIConnector:
    @pytest.mark.asyncio
    async def test_general_search(self):
        connector = SerpAPIConnector()
        serp_resp = make_response({
            "organic_results": [
                {
                    "title": "John Doe - Software Engineer",
                    "link": "https://linkedin.com/in/johndoe",
                    "snippet": "Software engineer at ...",
                    "displayed_link": "linkedin.com",
                    "position": 1,
                    "date": "",
                }
            ]
        })

        with patch("app.connectors.serpapi.settings") as mock_settings:
            mock_settings.SERPAPI_KEY = "test-key"
            with patch.object(connector, "_get", return_value=serp_resp), \
                 patch.object(connector, "_throttle", return_value=None):
                result = await connector.run("johndoe")

        assert result.status == ConnectorStatus.SUCCESS
        assert result.data["total_results"] > 0


# ──────────────────────────────────────────────────────────────
# Sherlock
# ──────────────────────────────────────────────────────────────

class TestSherlockConnector:
    @pytest.mark.asyncio
    async def test_username_found(self):
        connector = SherlockConnector()
        mock_output = """
[+] GitHub: https://github.com/johndoe
[+] Twitter: https://twitter.com/johndoe
[+] Reddit: https://reddit.com/user/johndoe
[-] Instagram: Not found
        """.strip()

        with patch.object(connector, "_run_sherlock", return_value={
            "username": "johndoe",
            "found": [
                {"platform": "GitHub",  "url": "https://github.com/johndoe",  "username": "johndoe"},
                {"platform": "Twitter", "url": "https://twitter.com/johndoe", "username": "johndoe"},
                {"platform": "Reddit",  "url": "https://reddit.com/user/johndoe", "username": "johndoe"},
            ],
            "total_checked": 4,
        }):
            result = await connector.run("johndoe")

        assert result.status == ConnectorStatus.SUCCESS
        assert len(result.data["found"]) == 3
        platforms = [p["platform"] for p in result.data["found"]]
        assert "GitHub" in platforms
        assert "Twitter" in platforms


# ──────────────────────────────────────────────────────────────
# Availability / base connector
# ──────────────────────────────────────────────────────────────

class TestBaseConnector:
    def test_available_when_no_keys_required(self):
        connector = HaveIBeenPwnedConnector()
        # HIBP has no required_keys, so always available
        assert connector.is_available() is True

    def test_unavailable_when_keys_missing(self):
        connector = SerpAPIConnector()
        with patch("app.connectors.serpapi.settings") as mock_settings:
            mock_settings.SERPAPI_KEY = None
            assert connector.is_available() is False

    def test_skipped_result_when_unavailable(self):
        """Connector should return SKIPPED status when not configured."""
        import asyncio
        connector = SerpAPIConnector()
        with patch.object(connector, "is_available", return_value=False):
            result = asyncio.run(connector.run("test"))
        assert result.status == ConnectorStatus.SKIPPED
