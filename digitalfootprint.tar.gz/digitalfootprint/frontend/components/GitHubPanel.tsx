"use client";

import { Star, GitFork, Code2, Users, ExternalLink } from "lucide-react";
import type { GitHubProfile } from "@/lib/api";

export function GitHubPanel({ github }: { github: GitHubProfile }) {
  const topLangs = Object.entries(github.languages ?? {}).slice(0, 6);
  const totalBytes = topLangs.reduce((s, [, v]) => s + v, 0);

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <p className="section-title mb-0">GitHub Developer Footprint</p>
        <a
          href={`https://github.com/${github.username}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
        >
          @{github.username} <ExternalLink size={10} />
        </a>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <StatPill icon={Users} label="Followers" value={github.followers} />
        <StatPill icon={Code2} label="Repos"     value={github.public_repos} />
        <StatPill icon={Star}  label="Stars"     value={github.repos.reduce((s, r) => s + r.stars, 0)} />
      </div>

      {/* Language bar */}
      {topLangs.length > 0 && (
        <div className="mb-4">
          <p className="section-title">Languages</p>
          <div className="flex rounded-full overflow-hidden h-2 mb-2">
            {topLangs.map(([lang, bytes]) => (
              <div
                key={lang}
                style={{ width: `${(bytes / totalBytes) * 100}%`, background: LANG_COLORS[lang] ?? "#6366f1" }}
                title={`${lang}: ${((bytes / totalBytes) * 100).toFixed(1)}%`}
              />
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {topLangs.map(([lang, bytes]) => (
              <span key={lang} className="text-xs text-gray-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full" style={{ background: LANG_COLORS[lang] ?? "#6366f1" }} />
                {lang} {((bytes / totalBytes) * 100).toFixed(0)}%
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Top repos */}
      {github.repos.length > 0 && (
        <div className="mb-4">
          <p className="section-title">Top Repositories</p>
          <div className="space-y-2">
            {github.repos.slice(0, 5).map((repo) => (
              <a
                key={repo.name}
                href={repo.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start justify-between p-2.5 bg-gray-800/60 rounded-lg hover:bg-gray-800 transition-colors group"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-indigo-300 group-hover:text-indigo-200">
                    {repo.name}
                  </div>
                  {repo.description && (
                    <div className="text-xs text-gray-500 truncate mt-0.5">{repo.description}</div>
                  )}
                  {repo.topics.length > 0 && (
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {repo.topics.slice(0, 3).map((t) => (
                        <span key={t} className="badge badge-gray text-[10px]">{t}</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-500 shrink-0 ml-3">
                  <span className="flex items-center gap-0.5"><Star size={10} />{repo.stars}</span>
                  {repo.language && <span className="badge badge-gray">{repo.language}</span>}
                </div>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Commit emails */}
      {github.commit_emails.length > 0 && (
        <div>
          <p className="section-title">Commit Email Addresses</p>
          <div className="space-y-1">
            {github.commit_emails.map((ce, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <span className="font-mono text-gray-300">{ce.email}</span>
                <span className="text-gray-600">{ce.commit_count} commits</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatPill({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: number }) {
  return (
    <div className="bg-gray-800/50 rounded-lg p-2.5 text-center">
      <Icon size={14} className="text-indigo-400 mx-auto mb-1" />
      <div className="text-lg font-bold tabular-nums">{value.toLocaleString()}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}

const LANG_COLORS: Record<string, string> = {
  TypeScript: "#3178c6", JavaScript: "#f1e05a", Python: "#3572A5",
  Rust: "#dea584", Go: "#00ADD8", Java: "#b07219", "C++": "#f34b7d",
  Ruby: "#701516", Swift: "#fa7343", Kotlin: "#A97BFF", CSS: "#563d7c",
  HTML: "#e34c26", Shell: "#89e051", Dart: "#00B4AB",
};
