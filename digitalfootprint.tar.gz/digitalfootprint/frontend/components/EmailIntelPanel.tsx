"use client";

import { ShieldAlert, ShieldCheck, AlertTriangle } from "lucide-react";
import type { EmailIntelligence } from "@/lib/api";

export function EmailIntelPanel({ intel }: { intel: EmailIntelligence[] }) {
  const allBreaches = intel.flatMap((i) => i.breaches);
  const totalBreaches = intel.reduce((s, i) => s + i.breach_count, 0);
  const isCompromised = totalBreaches > 0;

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <p className="section-title mb-0">Email Intelligence</p>
        {isCompromised ? (
          <span className="badge badge-red flex items-center gap-1">
            <ShieldAlert size={11} /> {totalBreaches} breach{totalBreaches > 1 ? "es" : ""}
          </span>
        ) : (
          <span className="badge badge-green flex items-center gap-1">
            <ShieldCheck size={11} /> No breaches found
          </span>
        )}
      </div>

      {intel.map((emailIntel, idx) => (
        <div key={idx} className={idx > 0 ? "mt-4 pt-4 border-t border-gray-800" : ""}>
          <div className="flex items-center justify-between mb-3">
            <span className="font-mono text-sm text-gray-300">{emailIntel.email}</span>
            {emailIntel.hunter_score != null && (
              <span className="text-xs text-gray-500">
                Hunter score: <span className="text-white font-medium">{emailIntel.hunter_score}/100</span>
              </span>
            )}
          </div>

          {emailIntel.breaches.length > 0 ? (
            <div className="space-y-2">
              {emailIntel.breaches.map((breach, bi) => (
                <div key={bi} className="bg-red-950/30 border border-red-900/40 rounded-lg p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <AlertTriangle size={13} className="text-red-400 shrink-0" />
                        <span className="font-semibold text-sm text-red-300">{breach.name}</span>
                        {breach.is_verified && (
                          <span className="badge badge-red text-[10px]">verified</span>
                        )}
                        {breach.is_sensitive && (
                          <span className="badge badge-red text-[10px]">sensitive</span>
                        )}
                      </div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {breach.domain} · {breach.breach_date}
                      </div>
                    </div>
                  </div>
                  {breach.data_classes.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {breach.data_classes.map((dc) => (
                        <span key={dc} className="badge badge-red text-[10px]">{dc}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center gap-2 text-sm text-emerald-400">
              <ShieldCheck size={14} /> This email has not appeared in known data breaches.
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
