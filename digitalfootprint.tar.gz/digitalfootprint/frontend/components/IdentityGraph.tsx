"use client";

import { useEffect, useRef, useState } from "react";
import type { GraphNode, GraphEdge } from "@/lib/api";

interface Props {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

const NODE_COLORS: Record<string, string> = {
  person:   "#6366f1",
  email:    "#10b981",
  username: "#f59e0b",
  profile:  "#3b82f6",
};

const NODE_SIZES: Record<string, number> = {
  person:   14,
  email:    8,
  username: 8,
  profile:  7,
};

export function IdentityGraph({ nodes, edges }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [Graph, setGraph] = useState<React.ComponentType<unknown> | null>(null);
  const [dims, setDims] = useState({ width: 800, height: 600 });

  // Dynamically import react-force-graph (client-only)
  useEffect(() => {
    import("react-force-graph").then((mod) => {
      setGraph(() => mod.ForceGraph2D as React.ComponentType<unknown>);
    });
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver((entries) => {
      const { width, height } = entries[0].contentRect;
      setDims({ width, height });
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  if (nodes.length === 0) {
    return (
      <div className="card flex items-center justify-center h-64 text-gray-500">
        <div className="text-center">
          <p className="text-lg">No graph data available</p>
          <p className="text-sm mt-1">Identity graph is populated after search completes.</p>
        </div>
      </div>
    );
  }

  const graphData = {
    nodes: nodes.map((n) => ({
      ...n,
      color: NODE_COLORS[n.type] ?? "#6b7280",
      val:   NODE_SIZES[n.type]  ?? 6,
    })),
    links: edges.map((e) => ({
      source: e.source,
      target: e.target,
      label:  e.label,
    })),
  };

  return (
    <div className="card p-0 overflow-hidden">
      <div className="p-4 border-b border-gray-800 flex items-center justify-between">
        <p className="section-title mb-0">Identity Graph</p>
        <div className="flex gap-3 text-xs text-gray-500">
          {Object.entries(NODE_COLORS).map(([type, color]) => (
            <span key={type} className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
              {type}
            </span>
          ))}
        </div>
      </div>
      <div ref={containerRef} className="graph-container" style={{ height: 520 }}>
        {Graph && (
          // @ts-expect-error — ForceGraph2D types are loose
          <Graph
            graphData={graphData}
            width={dims.width}
            height={520}
            backgroundColor="#030712"
            nodeLabel={(n: GraphNode) => `${n.type}: ${n.label}`}
            nodeColor={(n: GraphNode & { color?: string }) => n.color ?? "#6366f1"}
            nodeVal={(n: GraphNode & { val?: number }) => n.val ?? 6}
            linkColor={() => "#374151"}
            linkLabel={(l: GraphEdge) => l.label}
            linkDirectionalArrowLength={4}
            linkDirectionalArrowRelPos={1}
            nodeCanvasObjectMode={() => "after"}
            nodeCanvasObject={(node: GraphNode & { x?: number; y?: number; color?: string }, ctx: CanvasRenderingContext2D) => {
              const label = node.label?.length > 20 ? node.label.slice(0, 18) + "…" : node.label;
              ctx.font = "9px Inter, sans-serif";
              ctx.fillStyle = "rgba(255,255,255,0.7)";
              ctx.textAlign = "center";
              ctx.fillText(label, node.x ?? 0, (node.y ?? 0) + 14);
            }}
            cooldownTicks={80}
            d3AlphaDecay={0.02}
            d3VelocityDecay={0.3}
          />
        )}
      </div>
    </div>
  );
}
