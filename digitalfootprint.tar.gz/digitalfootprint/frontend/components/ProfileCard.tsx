"use client";

import Image from "next/image";
import { MapPin, LinkIcon, Building2, Twitter } from "lucide-react";
import type { ResolvedProfile } from "@/lib/api";
import { ConfidenceBadge } from "./ConfidenceBadge";

export function ProfileCard({ profile }: { profile: ResolvedProfile }) {
  return (
    <div className="card">
      <div className="flex items-start gap-4">
        {/* Avatar */}
        <div className="shrink-0">
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.primary_identity ?? "avatar"}
              width={64}
              height={64}
              className="rounded-full border-2 border-gray-700"
            />
          ) : (
            <div className="w-16 h-16 rounded-full bg-indigo-900/50 border-2 border-indigo-700 flex items-center justify-center text-2xl font-bold text-indigo-300">
              {(profile.primary_identity ?? "?")[0]?.toUpperCase()}
            </div>
          )}
        </div>

        {/* Identity info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl font-bold truncate">
              {profile.primary_identity ?? "Unknown Identity"}
            </h2>
            <ConfidenceBadge score={profile.confidence_score} />
          </div>

          {profile.bio && (
            <p className="text-gray-400 text-sm mt-1 leading-relaxed line-clamp-2">
              {profile.bio}
            </p>
          )}

          <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-500">
            {profile.locations[0] && (
              <span className="flex items-center gap-1">
                <MapPin size={11} /> {profile.locations[0]}
              </span>
            )}
            {profile.websites[0] && (
              <a
                href={profile.websites[0]}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 hover:text-indigo-400 transition-colors"
              >
                <LinkIcon size={11} /> {profile.websites[0]}
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Identifiers */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-5 pt-5 border-t border-gray-800">
        <IdentifierBlock label="Emails" items={profile.emails} mono />
        <IdentifierBlock label="Usernames" items={profile.usernames.map(u => `@${u}`)} />
        <IdentifierBlock label="Names" items={profile.names} />
      </div>

      {/* Social profiles */}
      {profile.social_profiles.length > 0 && (
        <div className="mt-4 pt-4 border-t border-gray-800">
          <p className="section-title">Social presence ({profile.social_profiles.length})</p>
          <div className="flex flex-wrap gap-2">
            {profile.social_profiles.slice(0, 20).map((sp, i) => (
              <a
                key={i}
                href={sp.url}
                target="_blank"
                rel="noopener noreferrer"
                className="badge badge-blue hover:bg-blue-800/60 transition-colors"
              >
                {sp.platform}
              </a>
            ))}
            {profile.social_profiles.length > 20 && (
              <span className="badge badge-gray">+{profile.social_profiles.length - 20} more</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function IdentifierBlock({
  label,
  items,
  mono = false,
}: {
  label: string;
  items: string[];
  mono?: boolean;
}) {
  if (items.length === 0) return null;
  return (
    <div>
      <p className="section-title">{label}</p>
      <ul className="space-y-1">
        {items.slice(0, 5).map((item, i) => (
          <li
            key={i}
            className={`text-sm text-gray-300 truncate ${mono ? "font-mono text-xs" : ""}`}
          >
            {item}
          </li>
        ))}
        {items.length > 5 && (
          <li className="text-xs text-gray-600">+{items.length - 5} more</li>
        )}
      </ul>
    </div>
  );
}
