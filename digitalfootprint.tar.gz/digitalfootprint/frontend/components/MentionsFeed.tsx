"use client";

import { ExternalLink, Newspaper, Globe, Terminal, Code2 } from "lucide-react";
import type { ResolvedProfile, Mention } from "@/lib/api";

const SOURCE_ICONS: Record<string, React.ReactNode> = {
  news:        <Newspaper size={13} className="text-blue-400" />,
  hackernews:  <Terminal  size={13} className="text-orange-400" />,
  devto:       <Code2     size={13} className="text-purple-400" />,
  web:         <Globe     size={13} className="text-gray-400" />,
};

const SOURCE_LABELS: Record<string, string> = {
  news:       "News",
  hackernews: "HackerNews",
  devto:      "DEV.to",
  web:        "Web",
};

export function MentionsFeed({ profiles }: { profiles: ResolvedProfile[] }) {
  // Flatten all mentions from all profiles
  const allNews: Mention[] = [];
  const allWeb:  Mention[] = [];
  const allHN:   Mention[] = [];
  const allDev:  Mention[] = [];

  for (const p of profiles) {
    if (!p.mentions) continue;
    allNews.push(...(p.mentions.news_articles ?? []));
    allWeb.push(...(p.mentions.web_results ?? []));
    // Extended fields from news connector
    const hn  = (p.mentions as Record<string, unknown>).hackernews as Mention[] | undefined;
    const dev = (p.mentions as Record<string, unknown>).devto       as Mention[] | undefined;
    if (hn)  allHN.push(...hn);
    if (dev) allDev.push(...dev);
  }

  const sections = [
    { key: "news",       label: "News Articles",      items: allNews, icon: <Newspaper size={14} className="text-blue-400" /> },
    { key: "hackernews", label: "HackerNews",          items: allHN,  icon: <Terminal  size={14} className="text-orange-400" /> },
    { key: "devto",      label: "DEV.to Articles",     items: allDev, icon: <Code2     size={14} className="text-purple-400" /> },
    { key: "web",        label: "Web Results",         items: allWeb, icon: <Globe     size={14} className="text-gray-400" /> },
  ].filter((s) => s.items.length > 0);

  if (sections.length === 0) {
    return (
      <div className="card flex items-center justify-center h-48 text-gray-500">
        No mentions found across news, HackerNews, or web results.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {sections.map(({ key, label, items, icon }) => (
        <div key={key} className="card">
          <div className="flex items-center gap-2 mb-4">
            {icon}
            <p className="section-title mb-0">{label}</p>
            <span className="badge badge-gray ml-auto">{items.length}</span>
          </div>
          <div className="space-y-3">
            {items.slice(0, 15).map((item, i) => (
              <MentionRow key={i} item={item} sourceKey={key} />
            ))}
            {items.length > 15 && (
              <p className="text-xs text-gray-600 text-center pt-1">
                +{items.length - 15} more results
              </p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function MentionRow({ item, sourceKey }: { item: Mention; sourceKey: string }) {
  return (
    <a
      href={item.url}
      target="_blank"
      rel="noopener noreferrer"
      className="block p-3 bg-gray-800/40 rounded-lg hover:bg-gray-800 transition-colors group"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            {SOURCE_ICONS[sourceKey]}
            <span className="text-[10px] text-gray-500">
              {(item as Record<string, unknown>).source_name as string
                ?? (item as Record<string, unknown>).author as string
                ?? SOURCE_LABELS[sourceKey]}
            </span>
            {item.published_at && (
              <span className="text-[10px] text-gray-600">
                · {formatDate(item.published_at)}
              </span>
            )}
          </div>
          <div className="text-sm font-medium text-gray-200 group-hover:text-white line-clamp-1">
            {item.title}
          </div>
          {item.snippet && (
            <div className="text-xs text-gray-500 mt-0.5 line-clamp-2 leading-relaxed">
              {item.snippet}
            </div>
          )}
        </div>
        <ExternalLink size={13} className="text-gray-600 group-hover:text-gray-400 shrink-0 mt-0.5" />
      </div>
    </a>
  );
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  } catch {
    return iso;
  }
}
