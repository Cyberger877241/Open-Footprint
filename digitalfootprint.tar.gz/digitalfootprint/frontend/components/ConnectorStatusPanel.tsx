"use client";

import { CheckCircle2, XCircle, AlertCircle, SkipForward, Clock } from "lucide-react";

interface ConnectorResult {
  connector: string;
  status: string;
  error?: string;
  duration_ms?: number;
}

const STATUS_ICONS: Record<string, React.ReactNode> = {
  success:      <CheckCircle2 size={13} className="text-emerald-400" />,
  failed:       <XCircle      size={13} className="text-red-400" />,
  skipped:      <SkipForward  size={13} className="text-gray-500" />,
  rate_limited: <AlertCircle  size={13} className="text-yellow-400" />,
};

const CONNECTOR_LABELS: Record<string, string> = {
  haveibeenpwned: "Have I Been Pwned",
  hunter:         "Hunter.io",
  github:         "GitHub",
  sherlock:       "Sherlock",
  serpapi:        "SerpAPI",
  news:           "News / Content",
};

export function ConnectorStatusPanel({
  connectors,
  compact = false,
}: {
  connectors: ConnectorResult[];
  compact?: boolean;
}) {
  return (
    <div className={compact ? "" : "card"}>
      {!compact && <p className="section-title">Connector Status</p>}
      <div className="space-y-2">
        {connectors.map((c, i) => (
          <div
            key={i}
            className="flex items-center justify-between bg-gray-800/40 rounded-lg px-3 py-2"
          >
            <div className="flex items-center gap-2">
              {STATUS_ICONS[c.status] ?? <Clock size={13} className="text-gray-500" />}
              <span className="text-sm text-gray-300">
                {CONNECTOR_LABELS[c.connector] ?? c.connector}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              {c.error && !compact && (
                <span className="text-red-400 truncate max-w-[120px]" title={c.error}>
                  {c.error.slice(0, 30)}…
                </span>
              )}
              {c.duration_ms != null && (
                <span className="text-gray-600 tabular-nums">{c.duration_ms.toFixed(0)}ms</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
