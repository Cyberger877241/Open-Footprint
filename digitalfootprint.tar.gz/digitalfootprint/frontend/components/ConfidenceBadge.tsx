"use client";

interface Props {
  score: number;
  className?: string;
}

export function ConfidenceBadge({ score, className = "" }: Props) {
  const pct = Math.round(score * 100);

  const color =
    pct >= 75 ? "bg-emerald-900/60 text-emerald-300 border-emerald-700" :
    pct >= 50 ? "bg-yellow-900/60 text-yellow-300 border-yellow-700"   :
    pct >= 25 ? "bg-orange-900/60 text-orange-300 border-orange-700"    :
                "bg-gray-800 text-gray-400 border-gray-700";

  const label =
    pct >= 75 ? "High confidence" :
    pct >= 50 ? "Medium confidence" :
    pct >= 25 ? "Low confidence"  :
                "Very low";

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${color} ${className}`}>
      <span className="tabular-nums">{pct}%</span>
      <span className="opacity-70">{label}</span>
    </span>
  );
}
