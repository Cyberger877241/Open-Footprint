import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merge Tailwind classes safely */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a number with K/M suffixes */
export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

/** Detect query type from string content */
export function detectSearchType(query: string): "email" | "username" | "name" | "combined" {
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(query)) return "email";
  if (/\s/.test(query))                           return "name";
  if (/^@?\w[\w.\-_]{1,}$/.test(query))          return "username";
  return "combined";
}

/** Truncate a string to max length */
export function truncate(str: string, max = 60): string {
  return str.length > max ? str.slice(0, max - 1) + "…" : str;
}

/** Friendly duration string */
export function formatDuration(seconds: number): string {
  if (seconds < 60)  return `${seconds.toFixed(1)}s`;
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}m ${s}s`;
}
