/**
 * DigitalFootprint — API Client
 * Typed wrapper around the FastAPI backend.
 */

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL
    ? `${process.env.NEXT_PUBLIC_API_URL}/api/v1`
    : "/api/v1";

// ─────────────────────────────────────────────────────────────
// Types (mirrors backend schemas)
// ─────────────────────────────────────────────────────────────

export type SearchType = "email" | "username" | "name" | "combined";
export type JobStatus  = "pending" | "running" | "completed" | "failed" | "partial";

export interface SearchRequest {
  query: string;
  search_type?: SearchType;
  include_connectors?: string[];
  max_depth?: number;
}

export interface SearchJobResponse {
  job_id: string;
  status: JobStatus;
  message: string;
  created_at: string;
}

export interface SocialProfile {
  platform: string;
  username: string;
  url: string;
  exists: boolean;
  profile_data: Record<string, unknown>;
}

export interface BreachRecord {
  name: string;
  domain: string;
  breach_date?: string;
  description?: string;
  data_classes: string[];
  is_verified: boolean;
  is_sensitive: boolean;
}

export interface EmailIntelligence {
  email: string;
  breaches: BreachRecord[];
  breach_count: number;
  hunter_score?: number;
}

export interface GitHubProfile {
  username: string;
  name?: string;
  bio?: string;
  avatar_url?: string;
  location?: string;
  company?: string;
  blog?: string;
  public_repos: number;
  followers: number;
  following: number;
  repos: Array<{
    name: string;
    url: string;
    stars: number;
    language?: string;
    description?: string;
    topics: string[];
  }>;
  commit_emails: Array<{ email: string; commit_count: number; repos: string[] }>;
  languages: Record<string, number>;
  organizations: Array<{ login: string; avatar_url?: string; url: string }>;
}

export interface Mention {
  title: string;
  url: string;
  source: string;
  snippet?: string;
  published_at?: string;
  source_type?: string;
}

export interface ResolvedProfile {
  profile_id: string;
  confidence_score: number;
  emails: string[];
  usernames: string[];
  names: string[];
  locations: string[];
  websites: string[];
  github?: GitHubProfile;
  email_intel: EmailIntelligence[];
  social_profiles: SocialProfile[];
  mentions?: {
    query: string;
    news_articles: Mention[];
    web_results: Mention[];
    total_mentions: number;
    hackernews?: Mention[];
    devto?: Mention[];
  };
  avatar_url?: string;
  bio?: string;
  primary_identity?: string;
}

export interface GraphNode {
  id: string;
  label: string;
  type: "person" | "email" | "username" | "profile";
  confidence?: number;
  platform?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  label: string;
  confidence?: number;
}

export interface SearchResult {
  job_id: string;
  query: string;
  search_type: SearchType;
  status: JobStatus;
  created_at: string;
  completed_at?: string;
  duration_seconds?: number;
  profiles: ResolvedProfile[];
  connector_results: Array<{
    connector: string;
    status: string;
    data: Record<string, unknown>;
    error?: string;
    duration_ms?: number;
  }>;
  graph_nodes: GraphNode[];
  graph_edges: GraphEdge[];
  total_emails: number;
  total_profiles: number;
  total_mentions: number;
  overall_confidence: number;
  agent_summary?: string;
  error?: string;
}

export interface ConnectorInfo {
  name: string;
  description: string;
  available: boolean;
  required_keys: string[];
}

// ─────────────────────────────────────────────────────────────
// API functions
// ─────────────────────────────────────────────────────────────

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || `API error ${res.status}`);
  }
  return res.json();
}

export const api = {
  /** Submit a new search job */
  search: (req: SearchRequest) =>
    apiFetch<SearchJobResponse>("/search", {
      method: "POST",
      body: JSON.stringify(req),
    }),

  /** Poll a search job for results */
  getResult: (jobId: string) =>
    apiFetch<SearchResult>(`/result/${jobId}`),

  /** List recent jobs */
  listJobs: (limit = 20) =>
    apiFetch<{ total: number; jobs: Array<Record<string, unknown>> }>(`/jobs?limit=${limit}`),

  /** Delete a job */
  deleteJob: (jobId: string) =>
    fetch(`${API_BASE}/jobs/${jobId}`, { method: "DELETE" }),

  /** Get connector availability */
  getConnectors: () =>
    apiFetch<{ connectors: ConnectorInfo[] }>("/connectors"),

  /** Health check */
  health: () =>
    apiFetch<{ status: string; services: Record<string, string> }>("/health".replace("/v1", "")),
};
