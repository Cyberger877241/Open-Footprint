"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Clock, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { api, SearchResult, JobStatus } from "@/lib/api";
import { ConfidenceBadge }    from "@/components/ConfidenceBadge";
import { ProfileCard }         from "@/components/ProfileCard";
import { ConnectorStatusPanel } from "@/components/ConnectorStatusPanel";
import { IdentityGraph }       from "@/components/IdentityGraph";
import { MentionsFeed }        from "@/components/MentionsFeed";
import { GitHubPanel }         from "@/components/GitHubPanel";
import { EmailIntelPanel }     from "@/components/EmailIntelPanel";

const POLL_INTERVAL_MS = 2500;

export default function ResultPage() {
  const { id } = useParams<{ id: string }>();
  const router  = useRouter();
  const [result, setResult]   = useState<SearchResult | null>(null);
  const [error, setError]     = useState<string | null>(null);
  const [activeTab, setTab]   = useState<"overview" | "graph" | "mentions" | "raw">("overview");

  const poll = useCallback(async () => {
    try {
      const data = await api.getResult(id);
      setResult(data as SearchResult);
      return data.status as JobStatus;
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to fetch result");
      return "failed" as JobStatus;
    }
  }, [id]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    const tick = async () => {
      const status = await poll();
      if (status === "pending" || status === "running") {
        timer = setTimeout(tick, POLL_INTERVAL_MS);
      }
    };

    tick();
    return () => clearTimeout(timer);
  }, [poll]);

  const status = result?.status ?? "pending";
  const isPending  = status === "pending" || status === "running";
  const isComplete = status === "completed";
  const isFailed   = status === "failed";

  return (
    <main className="min-h-screen">
      {/* Top bar */}
      <header className="border-b border-gray-800 px-6 py-4 flex items-center gap-4">
        <button
          onClick={() => router.push("/")}
          className="text-gray-400 hover:text-white transition-colors flex items-center gap-1.5 text-sm"
        >
          <ArrowLeft size={15} /> Back
        </button>
        <div className="h-4 w-px bg-gray-700" />
        <span className="font-mono text-gray-300 text-sm truncate max-w-md">
          {result?.query ?? id}
        </span>
        <StatusBadge status={status} />
        {isComplete && result && (
          <ConfidenceBadge score={result.overall_confidence} className="ml-auto" />
        )}
      </header>

      {/* Loading state */}
      {isPending && (
        <div className="flex flex-col items-center justify-center py-32 gap-6">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-4 border-indigo-900 pulse-ring absolute inset-0" />
            <div className="w-16 h-16 rounded-full border-4 border-t-indigo-500 border-indigo-900 animate-spin" />
          </div>
          <div className="text-center">
            <p className="text-lg font-semibold">Gathering intelligence…</p>
            <p className="text-gray-500 text-sm mt-1">Running connectors in parallel. This may take 30–60 seconds.</p>
          </div>
          {result?.connector_results && result.connector_results.length > 0 && (
            <ConnectorStatusPanel connectors={result.connector_results} compact />
          )}
        </div>
      )}

      {/* Error state */}
      {isFailed && (
        <div className="flex flex-col items-center justify-center py-32 gap-4">
          <XCircle size={48} className="text-red-500" />
          <p className="text-lg font-semibold">Search failed</p>
          <p className="text-gray-400 text-sm">{result?.error ?? error}</p>
          <button onClick={() => router.push("/")} className="btn-primary mt-2">
            Try again
          </button>
        </div>
      )}

      {/* Results */}
      {isComplete && result && (
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Stats row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <StatCard label="Profiles found"  value={result.total_profiles}  />
            <StatCard label="Emails linked"   value={result.total_emails}    />
            <StatCard label="Mentions found"  value={result.total_mentions}  />
            <StatCard label="Duration"        value={`${result.duration_seconds?.toFixed(1)}s`} />
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mb-6 bg-gray-900 rounded-lg p-1 w-fit">
            {(["overview", "graph", "mentions", "raw"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setTab(tab)}
                className={`px-4 py-2 rounded-md text-sm font-medium capitalize transition-colors ${
                  activeTab === tab
                    ? "bg-gray-700 text-white"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab content */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 space-y-6">
                {result.profiles.map((profile) => (
                  <div key={profile.profile_id} className="space-y-4">
                    <ProfileCard profile={profile} />
                    {profile.github && <GitHubPanel github={profile.github} />}
                    {profile.email_intel.length > 0 && (
                      <EmailIntelPanel intel={profile.email_intel} />
                    )}
                  </div>
                ))}
                {result.profiles.length === 0 && (
                  <div className="card text-center py-12 text-gray-500">
                    No profiles found for this query.
                  </div>
                )}
              </div>
              <div className="space-y-4">
                <ConnectorStatusPanel connectors={result.connector_results} />
                {result.agent_summary && (
                  <div className="card">
                    <p className="section-title">AI Summary</p>
                    <p className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap">
                      {result.agent_summary}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "graph" && (
            <IdentityGraph nodes={result.graph_nodes} edges={result.graph_edges} />
          )}

          {activeTab === "mentions" && (
            <MentionsFeed profiles={result.profiles} />
          )}

          {activeTab === "raw" && (
            <div className="card">
              <p className="section-title">Raw JSON</p>
              <pre className="text-xs text-gray-400 overflow-auto max-h-[70vh] font-mono">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}
    </main>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "pending" || status === "running")
    return <span className="badge badge-yellow"><Loader2 size={10} className="animate-spin" /> {status}</span>;
  if (status === "completed")
    return <span className="badge badge-green"><CheckCircle2 size={10} /> completed</span>;
  return <span className="badge badge-red"><XCircle size={10} /> failed</span>;
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card">
      <p className="section-title">{label}</p>
      <p className="text-2xl font-bold tabular-nums">{value}</p>
    </div>
  );
}
