"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Shield, GitBranch, Mail, Globe, Zap } from "lucide-react";
import { api, SearchType } from "@/lib/api";

const SEARCH_TYPES: { value: SearchType; label: string; placeholder: string }[] = [
  { value: "combined", label: "Auto-detect",  placeholder: 'e.g. "johndoe" or "john@example.com"' },
  { value: "username", label: "Username",     placeholder: 'e.g. "johndoe" or "@johndoe"' },
  { value: "email",    label: "Email",        placeholder: 'e.g. "john@example.com"' },
  { value: "name",     label: "Full name",    placeholder: 'e.g. "John Doe"' },
];

const FEATURES = [
  { icon: Mail,      label: "Email breaches",   desc: "HIBP + Hunter.io" },
  { icon: GitBranch, label: "Dev footprint",    desc: "GitHub + commit emails" },
  { icon: Globe,     label: "Username search",  desc: "300+ platforms via Sherlock" },
  { icon: Search,    label: "Web mentions",     desc: "News, HN, DEV.to, Google" },
  { icon: Shield,    label: "Identity graph",   desc: "Neo4j-powered link analysis" },
  { icon: Zap,       label: "Async pipeline",   desc: "Celery + Redis workers" },
];

export default function HomePage() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [searchType, setSearchType] = useState<SearchType>("combined");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const job = await api.search({ query: query.trim(), search_type: searchType });
      router.push(`/result/${job.job_id}`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Search failed");
      setLoading(false);
    }
  };

  const placeholder =
    SEARCH_TYPES.find((t) => t.value === searchType)?.placeholder ?? "";

  return (
    <main className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
            <Search size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">DigitalFootprint</span>
          <span className="badge badge-blue ml-1">OSINT</span>
        </div>
        <nav className="flex gap-4 text-sm text-gray-400">
          <a href="/docs" target="_blank" className="hover:text-white transition-colors">API Docs</a>
          <a href="https://github.com/your-org/digitalfootprint" target="_blank" className="hover:text-white transition-colors">GitHub</a>
        </nav>
      </header>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-20 max-w-3xl mx-auto w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-indigo-900/40 border border-indigo-700/50 rounded-full px-4 py-1.5 text-sm text-indigo-300 mb-6">
            <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse" />
            Open-source · Public data only · API-first
          </div>
          <h1 className="text-5xl font-extrabold tracking-tight mb-4 bg-gradient-to-br from-white to-gray-400 bg-clip-text text-transparent">
            OSINT at your fingertips
          </h1>
          <p className="text-xl text-gray-400 max-w-xl mx-auto">
            Aggregate digital identities from emails, usernames, and names using public data sources — automatically.
          </p>
        </div>

        {/* Search form */}
        <form onSubmit={handleSearch} className="w-full space-y-3">
          {/* Type selector */}
          <div className="flex gap-2">
            {SEARCH_TYPES.map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => setSearchType(t.value)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  searchType === t.value
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-800 text-gray-400 hover:text-white"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Input + submit */}
          <div className="flex gap-3">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={placeholder}
              className="input-field text-lg"
              autoFocus
              disabled={loading}
            />
            <button
              type="submit"
              className="btn-primary whitespace-nowrap flex items-center gap-2 px-6"
              disabled={loading || !query.trim()}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Searching…
                </>
              ) : (
                <>
                  <Search size={16} />
                  Search
                </>
              )}
            </button>
          </div>

          {error && (
            <p className="text-red-400 text-sm flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-red-400 rounded-full" />
              {error}
            </p>
          )}
        </form>

        {/* Feature grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-16 w-full">
          {FEATURES.map(({ icon: Icon, label, desc }) => (
            <div key={label} className="card flex items-start gap-3 group hover:border-gray-700 transition-colors">
              <div className="w-8 h-8 bg-indigo-900/50 rounded-lg flex items-center justify-center shrink-0 group-hover:bg-indigo-600/40 transition-colors">
                <Icon size={15} className="text-indigo-400" />
              </div>
              <div>
                <div className="text-sm font-semibold text-gray-100">{label}</div>
                <div className="text-xs text-gray-500 mt-0.5">{desc}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <p className="text-xs text-gray-600 text-center mt-10 max-w-lg">
          DigitalFootprint only accesses publicly available data and respects robots.txt, API rate limits, and platform Terms of Service.
          Use responsibly and in accordance with applicable laws.
        </p>
      </div>
    </main>
  );
}
